"use strict";
exports.id = 663;
exports.ids = [663];
exports.modules = {

/***/ 8663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export Button */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(387);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1088);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(primereact_button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);





const Button = (props)=>{
    const { sm , lg , block , outlined , href , text , rounded , access , clipBoardItems , clipBoardText , variant , className , onClick , ...rest } = props;
    const router = (0,next_dist_client_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const _onClick = (evt)=>{
        onClick && onClick(evt);
        if (href) {
            router.push(href);
        }
        if (props.clipBoardText) {
            navigator.clipboard.writeText(props.clipBoardText);
        }
        if (props.clipBoardItems) {
            navigator.clipboard.write(props.clipBoardItems);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_3__.Button, {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()({
            'p-button-rounded': rounded,
            [`p-button-${variant}`]: !!variant,
            'p-button-outlined': outlined,
            'p-button-text': text,
            'p-button-sm': sm,
            'p-button-lg': lg || false,
            'w-full': block
        }, className),
        onClick: _onClick,
        ...rest
    }));
};
Button.defaultProps = {
    type: 'button'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ })

};
;