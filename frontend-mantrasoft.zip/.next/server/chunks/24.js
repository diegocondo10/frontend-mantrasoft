"use strict";
exports.id = 24;
exports.ids = [24];
exports.modules = {

/***/ 3633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const ErrorMessage = ({ name  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_1__.ErrorMessage, {
        name: name,
        render: ({ message  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                className: "p-error",
                style: {
                    fontSize: '14px'
                },
                children: message
            })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorMessage);


/***/ }),

/***/ 6181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5927);
/* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_2__);



const ToatsTypes = [
    'Error',
    'Info',
    'Success',
    'Warning'
];
const useToasts = ()=>{
    const { addToast , ...rest } = (0,react_toast_notifications__WEBPACK_IMPORTED_MODULE_2__.useToasts)();
    const baseToast = ({ content , extraProps , callback  }, appearance)=>{
        addToast(content, {
            ...extraProps,
            appearance
        }, callback);
    };
    const buildToast = ()=>{
        const entries = ToatsTypes.map((toastType)=>{
            return [
                `add${toastType}Toast`,
                (content, extraProps, callback)=>{
                    baseToast({
                        content,
                        extraProps,
                        callback
                    }, toastType.toLowerCase());
                }, 
            ];
        });
        return Object.fromEntries(entries);
    };
    const addApiErrorToast = (error, { level ='warning' , path ='nonFieldErrors'  })=>{
        if (axios__WEBPACK_IMPORTED_MODULE_0___default().isAxiosError(error)) {
            var ref;
            baseToast({
                content: lodash__WEBPACK_IMPORTED_MODULE_1___default().get(error === null || error === void 0 ? void 0 : (ref = error.response) === null || ref === void 0 ? void 0 : ref.data, path, '')
            }, level);
        }
    };
    return {
        ...buildToast(),
        ...rest,
        addApiErrorToast
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useToasts);


/***/ })

};
;