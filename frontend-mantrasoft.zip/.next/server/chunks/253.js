"use strict";
exports.id = 253;
exports.ids = [253];
exports.modules = {

/***/ 8080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var primereact_progressspinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5767);
/* harmony import */ var primereact_progressspinner__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(primereact_progressspinner__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const Loading = (props)=>{
    if (!props.loading) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: props.children
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: {
            height: '100%',
            overflow: 'hidden'
        },
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('d-flex flex-column justify-content-center text-center', props === null || props === void 0 ? void 0 : props.className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_progressspinner__WEBPACK_IMPORTED_MODULE_2__.ProgressSpinner, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                children: props.texto
            })
        ]
    }));
};
Loading.defaultProps = {
    loading: false,
    texto: 'Cargando...'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 4000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const CONFIGS = {
    TOKEN_KEY: 'MANTRA-TOKEN',
    REFRESH_TOKEN_KEY: 'MANTRA-REFRES_TOKEN'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CONFIGS);


/***/ }),

/***/ 7877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_BaseLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/Loading.tsx
var Loading = __webpack_require__(8080);
// EXTERNAL MODULE: external "primereact/api"
var api_ = __webpack_require__(2250);
// EXTERNAL MODULE: external "primereact/scrolltop"
var scrolltop_ = __webpack_require__(8345);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/layouts/components/HeadHtml.tsx



const HeadHtml = (props)=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                charSet: "utf-8"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "viewport",
                content: "width=device-width, initial-scale=1.0"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                children: props.title
            }),
            props.children
        ]
    }));
};
HeadHtml.defaultProps = {
    title: 'Mantra'
};
/* harmony default export */ const components_HeadHtml = (HeadHtml);

;// CONCATENATED MODULE: ./src/layouts/BaseLayout.tsx






const BaseLayout = (props)=>{
    var ref;
    const headerRef = (0,external_react_.useRef)(null);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_HeadHtml, {
                title: props.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "d-flex flex-row vh-100 w-100",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "d-flex flex-column w-100",
                    children: [
                        props.header && /*#__PURE__*/ jsx_runtime_.jsx("header", {
                            ref: headerRef,
                            children: props.header
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                            ...props === null || props === void 0 ? void 0 : props.loading,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "m-0 p-0",
                                style: {
                                    overflowY: 'auto',
                                    height: `calc(100% - ${(headerRef === null || headerRef === void 0 ? void 0 : (ref = headerRef.current) === null || ref === void 0 ? void 0 : ref.offsetHeight) || 0})`,
                                    scrollBehavior: 'smooth'
                                },
                                children: [
                                    props.children,
                                    /*#__PURE__*/ jsx_runtime_.jsx(scrolltop_.ScrollTop, {
                                        target: "parent",
                                        threshold: 400,
                                        className: "p-button-primary bg-green-400",
                                        icon: api_.PrimeIcons.ARROW_UP
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const layouts_BaseLayout = (BaseLayout);


/***/ })

};
;