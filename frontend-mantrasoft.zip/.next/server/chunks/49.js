"use strict";
exports.id = 49;
exports.ids = [49];
exports.modules = {

/***/ 3049:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ formatearFechaBackend),
/* harmony export */   "p5": () => (/* binding */ formatearFechaFronend),
/* harmony export */   "$v": () => (/* binding */ generarFechasEntre)
/* harmony export */ });
/* unused harmony exports DATE_FORMAT, DATE_TIME_FORMAT */
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

const DATE_FORMAT = 'yyyy-MM-DD';
const DATE_TIME_FORMAT = 'yyyy-MM-DD HH:mm';
const formatearFechaBackend = (date = moment__WEBPACK_IMPORTED_MODULE_0___default()().toDate())=>moment__WEBPACK_IMPORTED_MODULE_0___default()(date).format(DATE_FORMAT)
;
const formatearFechaFronend = (date)=>moment__WEBPACK_IMPORTED_MODULE_0___default()(date).toDate()
;
const generarFechasEntre = (startDate, endDate)=>{
    const now = startDate.clone();
    const fechas = {
    };
    while(now.isSameOrBefore(endDate)){
        var ref;
        const values = {
            mesNumber: now.get('M'),
            mesStr: now.format('MMMM').toUpperCase(),
            diaNumber: now.format('DD'),
            diaSemanaStr: now.format('dd').toUpperCase(),
            dateStr: now.format('YYYY-MM-DD')
        };
        const dias = (fechas === null || fechas === void 0 ? void 0 : (ref = fechas[values.mesStr]) === null || ref === void 0 ? void 0 : ref.dias) || [];
        dias.push({
            str: values.diaSemanaStr,
            number: values.diaNumber,
            date: values.dateStr
        });
        fechas[values.mesStr] = {
            str: values.mesStr,
            number: values.mesNumber,
            dias: dias
        };
        now.add(1, 'days');
    }
    return fechas;
};


/***/ })

};
;