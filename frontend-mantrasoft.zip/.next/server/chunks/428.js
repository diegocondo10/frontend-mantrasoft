"use strict";
exports.id = 428;
exports.ids = [428];
exports.modules = {

/***/ 9851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8145);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(primereact_column__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const ColumnaNo = (props = null)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_1__.Column, {
        header: "No",
        bodyClassName: "text-center",
        headerClassName: "text-center",
        style: {
            width: props === null || props === void 0 ? void 0 : props.width
        },
        body: (_, rowData)=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                className: "text-center",
                style: {
                    width: props === null || props === void 0 ? void 0 : props.width
                },
                children: //@ts-ignore
                (rowData === null || rowData === void 0 ? void 0 : rowData.rowIndex) + 1
            }));
        }
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ColumnaNo);


/***/ }),

/***/ 7495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7447);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(primereact_datatable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const defaultProps = {
    rowHover: true,
    paginator: true,
    autoLayout: true,
    stripedRows: true,
    showGridlines: true,
    currentPageReportTemplate: '{currentPage} de {totalPages} | Registros totales {totalRecords}',
    paginatorTemplate: 'FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink',
    sortMode: 'multiple',
    emptyMessage: 'No se ha encontrado informaci\xf3n',
    lazy: true,
    removableSort: true
};
const TablaPaginada = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default().forwardRef((props, ref)=>{
    const { onOrdering , onChangePage , ...rest } = props;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_datatable__WEBPACK_IMPORTED_MODULE_1__.DataTable, {
        ...rest,
        onSort: (e)=>onOrdering(e.multiSortMeta)
        ,
        onPage: (e)=>onChangePage(e.page)
        ,
        ...rest,
        children: props.children
    }));
});
TablaPaginada.defaultProps = defaultProps;
TablaPaginada.displayName = 'TablaPaginada';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TablaPaginada);


/***/ }),

/***/ 7914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_services_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8469);




const usePagination = ({ uri: uri1 , key  })=>{
    const { 0: page1 , 1: setPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: ordering1 , 1: setOrdering  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: search1 , 1: changeSearch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: filters1 , 1: setFilters  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    });
    const construirUrl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(({ uri , page , ordering , search , filters ={
    }  })=>{
        const object = {
        };
        if (ordering && (ordering === null || ordering === void 0 ? void 0 : ordering.length) > 0) {
            object.ordering = ordering.map((sort)=>`${sort.order === 1 ? '' : '-'}${sort.field}`
            ).join(',');
        }
        if (page && page > 0) {
            object.page = page + 1;
        }
        if (search && search !== '') {
            object.search = search;
        }
        const entries = Object.entries(filters);
        if (entries.length > 0) {
            entries.forEach(([key, value])=>{
                if (value) object[key] = value;
            });
        }
        const qString = new URLSearchParams(object).toString();
        const qParams = qString ? `?${qString}` : '';
        return uri + qParams;
    }, []);
    const response = (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)([
        key,
        page1,
        ordering1,
        search1,
        filters1
    ], ()=>{
        const CancelToken = (axios__WEBPACK_IMPORTED_MODULE_0___default().CancelToken);
        const source = CancelToken.source();
        const promise = src_services_api__WEBPACK_IMPORTED_MODULE_3__/* ["default"]["private"] */ .Z["private"]({
            cancelToken: source.token
        }).get(construirUrl({
            uri: uri1,
            page: page1,
            ordering: ordering1,
            search: search1,
            filters: filters1
        }));
        //@ts-ignore
        promise.cancel = ()=>{
            source.cancel('Query was cancelled by React Query');
        };
        return promise;
    }, {
        keepPreviousData: true,
        cacheTime: 0,
        refetchOnWindowFocus: false,
        isDataEqual: ()=>false
    });
    return {
        ...response,
        setPage,
        page: page1,
        setOrdering,
        ordering: ordering1,
        setSearch (evt) {
            var ref;
            if (evt === null || evt === void 0 ? void 0 : (ref = evt.target) === null || ref === void 0 ? void 0 : ref.value) {
                var ref1;
                return changeSearch(`${evt === null || evt === void 0 ? void 0 : (ref1 = evt.target) === null || ref1 === void 0 ? void 0 : ref1.value}`);
            }
            changeSearch('');
        },
        filters: filters1,
        changeFilter (evt) {
            var ref;
            setFilters({
                ...filters1,
                [evt.target.name]: (evt === null || evt === void 0 ? void 0 : (ref = evt.target) === null || ref === void 0 ? void 0 : ref.value) || null
            });
        },
        setFilters,
        search: search1
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (usePagination);


/***/ })

};
;