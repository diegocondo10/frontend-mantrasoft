"use strict";
exports.id = 469;
exports.ids = [469];
exports.modules = {

/***/ 8469:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_constants_configs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4000);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _urls__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6102);



const API = {
    public (configs) {
        return axios__WEBPACK_IMPORTED_MODULE_1___default().create({
            baseURL: `${_urls__WEBPACK_IMPORTED_MODULE_2__/* .URL_BASE */ .Le}api/`,
            responseType: 'json',
            ...configs
        });
    },
    private (configs) {
        return this.public({
            headers: {
                Authorization: `Bearer ${localStorage.getItem(_src_constants_configs__WEBPACK_IMPORTED_MODULE_0__/* ["default"].TOKEN_KEY */ .Z.TOKEN_KEY)}`
            },
            ...configs
        });
    },
    getReporte (url) {
        return async (evt)=>{
            if (evt === null || evt === void 0 ? void 0 : evt.target) {
                const target = evt.target;
                target.parentElement.disabled = true;
                target.disabled = true;
                target.parentElement.classList.add('test');
                target.classList.add('test');
            }
            try {
                const res = await API.private({
                    responseType: 'blob'
                }).get(url);
                const objUrl = window.URL.createObjectURL(res.data);
                window.open(objUrl);
            } catch (error) {
                alert('Ha ocurrido un problema al generar el reporte');
            }
            setTimeout(()=>{
                if (evt === null || evt === void 0 ? void 0 : evt.target) {
                    const target = evt.target;
                    target.parentElement.disabled = false;
                    target.disabled = false;
                    target.parentElement.classList.remove('test');
                    target.classList.remove('test');
                }
            }, 100);
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (API);


/***/ }),

/***/ 6102:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Le": () => (/* binding */ URL_BASE),
/* harmony export */   "s3": () => (/* binding */ urlLogin),
/* harmony export */   "xG": () => (/* binding */ urlListarPersonas),
/* harmony export */   "sT": () => (/* binding */ urlCreatePersona),
/* harmony export */   "LF": () => (/* binding */ urlUpdatePersona),
/* harmony export */   "Q4": () => (/* binding */ urlDeletePersona),
/* harmony export */   "BM": () => (/* binding */ urlDetailPersona),
/* harmony export */   "ao": () => (/* binding */ urlCatalogoCreate),
/* harmony export */   "Qu": () => (/* binding */ urlListadoFilterPacientes),
/* harmony export */   "kW": () => (/* binding */ urlListarHabitaciones),
/* harmony export */   "I3": () => (/* binding */ urlListarAlasLabelValueHabitaciones),
/* harmony export */   "w6": () => (/* binding */ urlCreateHabitacion),
/* harmony export */   "CH": () => (/* binding */ urlUpdateHabitacion),
/* harmony export */   "oH": () => (/* binding */ urlDeleteHabitacion),
/* harmony export */   "a2": () => (/* binding */ urlDetailHabitacion),
/* harmony export */   "Nj": () => (/* binding */ urlListarMedicamentos),
/* harmony export */   "FV": () => (/* binding */ urlCreateMedicamento),
/* harmony export */   "Ps": () => (/* binding */ urlUpdateMedicamento),
/* harmony export */   "sM": () => (/* binding */ urlDeleteMedicamento),
/* harmony export */   "aP": () => (/* binding */ urlDetailMedicamento),
/* harmony export */   "cA": () => (/* binding */ urlPersonalAutorizadoMedicamentos),
/* harmony export */   "qd": () => (/* binding */ urlMedicamentosLabelValue),
/* harmony export */   "QR": () => (/* binding */ urlListarFichasIngreso),
/* harmony export */   "So": () => (/* binding */ urlCatalogoForm),
/* harmony export */   "is": () => (/* binding */ urlInfoPacienteFichaIngreso),
/* harmony export */   "X4": () => (/* binding */ urlCreateFichasIngreso),
/* harmony export */   "fY": () => (/* binding */ urlUpdateFichasIngreso),
/* harmony export */   "Bc": () => (/* binding */ urlDeleteFichasIngreso),
/* harmony export */   "tF": () => (/* binding */ urlDetailFichasIngreso),
/* harmony export */   "Ad": () => (/* binding */ urlImprimirFichaIngreso),
/* harmony export */   "$O": () => (/* binding */ urlImprimirReporteEnfermeria),
/* harmony export */   "D": () => (/* binding */ urlImprimirControlMedicacion),
/* harmony export */   "mT": () => (/* binding */ urlSeguimientosEnfermeriaPaciente),
/* harmony export */   "JH": () => (/* binding */ urlInfoPacienteByIdFicha),
/* harmony export */   "SX": () => (/* binding */ urlSignosPorSemana),
/* harmony export */   "f7": () => (/* binding */ urlImprimirReporteSignosVitalesSemana),
/* harmony export */   "JM": () => (/* binding */ urlRegistrarSignoVital),
/* harmony export */   "FQ": () => (/* binding */ urlGetSignos),
/* harmony export */   "e3": () => (/* binding */ urlGetSignoVital),
/* harmony export */   "PL": () => (/* binding */ urlResumenEnfermera),
/* harmony export */   "Xg": () => (/* binding */ urlCreatePertenencia),
/* harmony export */   "r9": () => (/* binding */ urlUpdatePertenencia),
/* harmony export */   "zm": () => (/* binding */ urlImprimirFichaSalida),
/* harmony export */   "IB": () => (/* binding */ urlListarPermisos),
/* harmony export */   "ER": () => (/* binding */ urlCreatePermiso),
/* harmony export */   "c7": () => (/* binding */ urlUpdatePermiso),
/* harmony export */   "bf": () => (/* binding */ urlListarRolesSistema),
/* harmony export */   "Qb": () => (/* binding */ urlCreateRolesSistema),
/* harmony export */   "RP": () => (/* binding */ urlCatalogoFormRolesSistema),
/* harmony export */   "K$": () => (/* binding */ urlUpdateRolesSistema),
/* harmony export */   "x6": () => (/* binding */ urlDeleteRolesSistema),
/* harmony export */   "D7": () => (/* binding */ urlListarUsuarios),
/* harmony export */   "xg": () => (/* binding */ urlCreateUsuarios),
/* harmony export */   "R0": () => (/* binding */ urlCatalogoFormUsuarios),
/* harmony export */   "jN": () => (/* binding */ urlUpdateUsuarios),
/* harmony export */   "OL": () => (/* binding */ urlDeleteUsuarios),
/* harmony export */   "G9": () => (/* binding */ urlReiniciarPasswordUsuario),
/* harmony export */   "P5": () => (/* binding */ urlPerfil),
/* harmony export */   "Ib": () => (/* binding */ urlParametrosGeneracionHorario),
/* harmony export */   "Vz": () => (/* binding */ urlConsultarHorarios),
/* harmony export */   "Ck": () => (/* binding */ urlUpdateOrCreateHorario),
/* harmony export */   "XD": () => (/* binding */ urlDetalleHorario),
/* harmony export */   "vo": () => (/* binding */ urlSeguimientosPacienteHorarios),
/* harmony export */   "Qs": () => (/* binding */ urlCreateSeguimientoEnfermeria),
/* harmony export */   "Wo": () => (/* binding */ urlUpdateSeguimientoEnfermeria),
/* harmony export */   "E5": () => (/* binding */ urlDeleteSeguimientoEnfermeria),
/* harmony export */   "fz": () => (/* binding */ urlGetTratamientoInicial),
/* harmony export */   "$8": () => (/* binding */ urlCreateOrUpdateTratamientoInicial),
/* harmony export */   "kI": () => (/* binding */ urlMedicamentosPaciente),
/* harmony export */   "nZ": () => (/* binding */ urlRegistrarMedicacion)
/* harmony export */ });
/* unused harmony exports urlListarPertenencias, urlDeletePermiso, urlDetailPermiso, urlDetailRolesSistema, urlDetailUsuarios */
// export const URL_BASE = 'http://localhost:8000/';
const URL_BASE = 'http://backendmantra-env.eba-ye3rkbaj.us-east-1.elasticbeanstalk.com/';
const PERMISOS = 'permisos/';
const ROLES_SISTEMA = 'roles-sistema/';
const USUARIOS = 'usuarios/';
const PERSONAS = 'personas/';
const HABITACIONES = 'habitaciones/';
const MEDICAMENTOS = 'medicamentos/';
const FICHAS_INGRESO = 'fichas-ingreso/';
const PERTENENECIAS = 'pertenencias/';
const ALAS = 'alas/';
const HORARIOS = 'horarios/';
const SEGUIMIENTOS_ENFERMERIA = `seguimientos-enfermeria/`;
const TRATAMIENTOS_BASE = `tratamientos-base/`;
const SIGNO_VITALES = 'signos-vitales/';
/**
 * AUTH
 */ const urlLogin = `${USUARIOS}login/`;
/**
 * PERSONAS
 */ const urlListarPersonas = PERSONAS;
const urlCreatePersona = PERSONAS;
const urlUpdatePersona = (id)=>`${PERSONAS}${id}/`
;
const urlDeletePersona = urlUpdatePersona;
const urlDetailPersona = urlUpdatePersona;
const urlCatalogoCreate = `${PERSONAS}catalogo-create/`;
/**
 * ALAS
 */ //LIST PACIENTES
const urlListadoFilterPacientes = `${ALAS}listado-filter-pacientes/`;
/**
 * HABITACIONES
 */ const urlListarHabitaciones = HABITACIONES;
const urlListarAlasLabelValueHabitaciones = `${HABITACIONES}listar-alas/`;
const urlCreateHabitacion = HABITACIONES;
const urlUpdateHabitacion = (id)=>`${HABITACIONES}${id}/`
;
const urlDeleteHabitacion = urlUpdateHabitacion;
const urlDetailHabitacion = urlUpdateHabitacion;
/**
 * MEDICAMENTOS
 */ const urlListarMedicamentos = MEDICAMENTOS;
const urlCreateMedicamento = MEDICAMENTOS;
const urlUpdateMedicamento = (id)=>`${MEDICAMENTOS}${id}/`
;
const urlDeleteMedicamento = urlUpdateMedicamento;
const urlDetailMedicamento = urlUpdateMedicamento;
const urlPersonalAutorizadoMedicamentos = `${MEDICAMENTOS}personal-autorizado/`;
const urlMedicamentosLabelValue = `${MEDICAMENTOS}label-value/`;
/**
 * PACIENTES
 */ //FICHAS DE INGRESO
const urlListarFichasIngreso = FICHAS_INGRESO;
const urlCatalogoForm = `${FICHAS_INGRESO}catalogo-form-ficha/`;
const urlInfoPacienteFichaIngreso = (id)=>`${FICHAS_INGRESO}${id}/info-paciente/`
;
const urlCreateFichasIngreso = FICHAS_INGRESO;
const urlUpdateFichasIngreso = (id)=>`${FICHAS_INGRESO}${id}/`
;
const urlDeleteFichasIngreso = urlUpdateFichasIngreso;
const urlDetailFichasIngreso = urlUpdateFichasIngreso;
const urlImprimirFichaIngreso = (id)=>`${urlUpdateFichasIngreso(id)}imprimir-ficha/`
;
const urlImprimirReporteEnfermeria = (id)=>`${urlUpdateFichasIngreso(id)}imprimir-reporte-enfermeria/`
;
const urlImprimirControlMedicacion = (id, mes, anio)=>{
    return `${urlUpdateFichasIngreso(id)}imprimir-control-medicacion/${mes}/${anio}/`;
};
const urlSeguimientosEnfermeriaPaciente = (id)=>`${urlUpdateFichasIngreso(id)}seguimientos/`
;
const urlInfoPacienteByIdFicha = (id)=>`${urlUpdateFichasIngreso(id)}info-paciente-signos/`
;
const urlSignosPorSemana = (week, pacienteId)=>{
    return `${SIGNO_VITALES}info-semana/${week}/${pacienteId}/`;
};
const urlImprimirReporteSignosVitalesSemana = (week, pacienteId)=>{
    return `${SIGNO_VITALES}imprimir-reporte-semanal/${week}/${pacienteId}/`;
};
const urlRegistrarSignoVital = `signos-vitales/registrar/`;
const urlGetSignos = (fecha, paciente)=>{
    return `signos-vitales/get-signos/${fecha}/${paciente}/`;
};
const urlGetSignoVital = (fecha, paciente, tipo)=>{
    return `signos-vitales/${fecha}/${paciente}/${tipo}/`;
};
const urlResumenEnfermera = (pacienteId, fecha)=>{
    return `${FICHAS_INGRESO}resumen/${pacienteId}/${fecha}`;
};
//PERTENENCIAS
const urlListarPertenencias = (id)=>`${PERTENENECIAS}?id_registro=${id}`
;
const urlCreatePertenencia = PERTENENECIAS;
const urlUpdatePertenencia = (id)=>`${PERTENENECIAS}${id}/`
;
const urlImprimirFichaSalida = (id)=>`${FICHAS_INGRESO}${id}/imprimir/ficha/salida`
;
/**
 * AUDITORIA
 */ //PERMISOS
const urlListarPermisos = PERMISOS;
const urlCreatePermiso = PERMISOS;
const urlUpdatePermiso = (id)=>`${PERMISOS}${id}/`
;
const urlDeletePermiso = (/* unused pure expression or super */ null && (urlUpdatePermiso));
const urlDetailPermiso = (/* unused pure expression or super */ null && (urlUpdatePermiso));
//ROLES DEL SISTEMA
const urlListarRolesSistema = ROLES_SISTEMA;
const urlCreateRolesSistema = ROLES_SISTEMA;
const urlCatalogoFormRolesSistema = `${ROLES_SISTEMA}catalogo-form/`;
const urlUpdateRolesSistema = (id)=>`${ROLES_SISTEMA}${id}/`
;
const urlDeleteRolesSistema = urlUpdateRolesSistema;
const urlDetailRolesSistema = (/* unused pure expression or super */ null && (urlUpdateRolesSistema));
//USUARIOS
const urlListarUsuarios = USUARIOS;
const urlCreateUsuarios = USUARIOS;
const urlCatalogoFormUsuarios = `${USUARIOS}catalogo-form/`;
const urlUpdateUsuarios = (id)=>`${USUARIOS}${id}/`
;
const urlDeleteUsuarios = urlUpdateUsuarios;
const urlDetailUsuarios = (/* unused pure expression or super */ null && (urlUpdateUsuarios));
const urlReiniciarPasswordUsuario = (id)=>`${USUARIOS}${id}/reset-password/`
;
const urlPerfil = `${USUARIOS}perfil/`;
/**
 * HORARIOS
 */ const urlParametrosGeneracionHorario = `${HORARIOS}parametros-generacion/`;
const urlConsultarHorarios = (startDate, endDate)=>{
    return `${HORARIOS}personal/${startDate}/${endDate}/`;
};
const urlUpdateOrCreateHorario = `${HORARIOS}update-or-create/`;
const urlDetalleHorario = (id, startDate, endDate)=>{
    return `${HORARIOS}detalle/${id}/${startDate}/${endDate}/`;
};
/**
 * SEGUIMIENTOS DE ENFERMERIA
 */ const urlSeguimientosPacienteHorarios = (fecha, idPaciente)=>{
    return `${HORARIOS}seguimientos-paciente-horario/${fecha}/${idPaciente}/`;
};
const urlCreateSeguimientoEnfermeria = SEGUIMIENTOS_ENFERMERIA;
const urlUpdateSeguimientoEnfermeria = (id)=>{
    return `${SEGUIMIENTOS_ENFERMERIA}${id}/`;
};
const urlDeleteSeguimientoEnfermeria = urlUpdateSeguimientoEnfermeria;
/**
 *
 * TRATAMIENTOS
 *
 */ const urlGetTratamientoInicial = (idFicha)=>`${TRATAMIENTOS_BASE}${idFicha}/`
;
const urlCreateOrUpdateTratamientoInicial = urlGetTratamientoInicial;
const urlMedicamentosPaciente = (fecha)=>`${TRATAMIENTOS_BASE}medicamentos/${fecha}/`
;
const urlRegistrarMedicacion = (idPaciente)=>`${TRATAMIENTOS_BASE}registrar-medicacion/${idPaciente}/`
;


/***/ })

};
;