"use strict";
exports.id = 630;
exports.ids = [630];
exports.modules = {

/***/ 1630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_PrivateLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/Button.tsx
var Button = __webpack_require__(8663);
// EXTERNAL MODULE: ./src/store/usuario/useUsuario.ts
var useUsuario = __webpack_require__(9755);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(387);
// EXTERNAL MODULE: external "primereact/api"
var api_ = __webpack_require__(2250);
// EXTERNAL MODULE: external "primereact/menubar"
var menubar_ = __webpack_require__(4130);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./src/components/Navbars/PrivateNavbar/index.tsx







const PrivateNavbar = ()=>{
    const router = (0,client_router.useRouter)();
    const { activarOptionNavbarByPermiso  } = (0,useUsuario/* default */.Z)();
    const mappItem = (item)=>{
        var ref, ref1;
        return {
            ...item,
            command: ()=>{
                if (item.url) {
                    router.push(item.url);
                }
            },
            url: undefined,
            items: (item === null || item === void 0 ? void 0 : (ref = item.items) === null || ref === void 0 ? void 0 : (ref1 = ref.map) === null || ref1 === void 0 ? void 0 : ref1.call(ref, mappItem)) || undefined
        };
    };
    const model = (0,external_react_.useMemo)(()=>[
            {
                icon: api_.PrimeIcons.HOME,
                label: 'Inicio',
                url: '/'
            },
            {
                icon: api_.PrimeIcons.FOLDER,
                label: 'Catalogos',
                items: [
                    {
                        icon: api_.PrimeIcons.USERS,
                        label: 'Personas',
                        url: '/personas/',
                        ...activarOptionNavbarByPermiso('PERSONAS__LISTAR')
                    },
                    {
                        label: 'Habitaciones',
                        icon: api_.PrimeIcons.LIST,
                        url: '/habitaciones/',
                        ...activarOptionNavbarByPermiso('HABITACIONES__LISTAR')
                    },
                    {
                        label: 'Horarios',
                        icon: api_.PrimeIcons.LIST,
                        url: '/horarios/',
                        ...activarOptionNavbarByPermiso('HORARIOS__LISTAR')
                    },
                    {
                        label: 'Medicamentos',
                        icon: api_.PrimeIcons.LIST,
                        url: '/medicamentos/',
                        ...activarOptionNavbarByPermiso('MEDICAMENTOS__LISTAR')
                    }, 
                ]
            },
            {
                icon: api_.PrimeIcons.FOLDER,
                label: 'Fichas',
                items: [
                    {
                        label: 'Ingreso',
                        icon: api_.PrimeIcons.FILE,
                        url: '/fichas/ingreso',
                        ...activarOptionNavbarByPermiso('FICHASINGRESO__LISTAR')
                    }, 
                ]
            },
            {
                icon: api_.PrimeIcons.LOCK,
                label: 'Auditoria',
                items: [
                    {
                        label: 'Permisos',
                        icon: api_.PrimeIcons.LOCK,
                        url: '/auditoria/permisos/',
                        ...activarOptionNavbarByPermiso('PERMISOS__LISTAR')
                    },
                    {
                        label: 'Roles del sistema',
                        icon: api_.PrimeIcons.LIST,
                        url: '/auditoria/roles-sistema/',
                        ...activarOptionNavbarByPermiso('ROLES__LISTAR')
                    },
                    {
                        label: 'Usuarios',
                        icon: api_.PrimeIcons.USERS,
                        url: '/auditoria/usuarios/',
                        ...activarOptionNavbarByPermiso('USUARIOS__LISTAR')
                    }, 
                ]
            }, 
        ].map(mappItem)
    , []);
    return(/*#__PURE__*/ jsx_runtime_.jsx(menubar_.Menubar, {
        model: model,
        end: /*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                outlined: true,
                sm: true,
                label: "Salir",
                icon: api_.PrimeIcons.POWER_OFF,
                variant: "danger",
                href: "/logout"
            })
        })
    }));
};
/* harmony default export */ const Navbars_PrivateNavbar = (PrivateNavbar);

// EXTERNAL MODULE: ./src/services/api.ts
var api = __webpack_require__(8469);
// EXTERNAL MODULE: ./src/services/urls.ts
var urls = __webpack_require__(6102);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: ./src/layouts/BaseLayout.tsx + 1 modules
var BaseLayout = __webpack_require__(7877);
;// CONCATENATED MODULE: ./src/layouts/PrivateLayout.tsx

/* eslint-disable react-hooks/exhaustive-deps */ 






const PrivateLayout = (props)=>{
    var ref, ref1;
    const { children , ...rest } = props;
    const { isValidSession , setUsuario  } = (0,useUsuario/* default */.Z)();
    const { isLoading  } = (0,external_react_query_.useQuery)([
        'perfil'
    ], ()=>api/* default.private */.Z["private"]().post(urls/* urlPerfil */.P5)
    , {
        refetchOnWindowFocus: false,
        onError: ()=>{
            console.log('ERROR');
        },
        onSuccess: ({ data  })=>{
            setUsuario(data);
        },
        enabled: isValidSession()
    });
    return(/*#__PURE__*/ jsx_runtime_.jsx(BaseLayout/* default */.Z, {
        ...rest,
        loading: {
            loading: isLoading || (props === null || props === void 0 ? void 0 : (ref = props.loading) === null || ref === void 0 ? void 0 : ref.loading),
            texto: props === null || props === void 0 ? void 0 : (ref1 = props.loading) === null || ref1 === void 0 ? void 0 : ref1.texto
        },
        children: children
    }));
};
PrivateLayout.defaultProps = {
    header: /*#__PURE__*/ jsx_runtime_.jsx(Navbars_PrivateNavbar, {
    })
};
/* harmony default export */ const layouts_PrivateLayout = (PrivateLayout);


/***/ }),

/***/ 9755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_constants_configs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4000);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


const useUsuario = ()=>{
    const usuarioJSON = localStorage.getItem('usuario') || null;
    const usuario = usuarioJSON !== null ? JSON.parse(usuarioJSON) : null;
    const isValidSession = ()=>{
        const access = localStorage.getItem(_src_constants_configs__WEBPACK_IMPORTED_MODULE_0__/* ["default"].TOKEN_KEY */ .Z.TOKEN_KEY);
        const refresh = localStorage.getItem(_src_constants_configs__WEBPACK_IMPORTED_MODULE_0__/* ["default"].REFRESH_TOKEN_KEY */ .Z.REFRESH_TOKEN_KEY);
        if (access && refresh) {
            return true;
        }
        next_router__WEBPACK_IMPORTED_MODULE_1___default().replace('/logout');
        return false;
    };
    const tienePermiso = (permiso)=>{
        var ref, ref1;
        return true;
        return usuario === null || usuario === void 0 ? void 0 : (ref = usuario.permisos) === null || ref === void 0 ? void 0 : (ref1 = ref.some) === null || ref1 === void 0 ? void 0 : ref1.call(ref, (item)=>item === permiso
        );
    };
    const tieneRol = (rol)=>{
        var ref, ref2;
        return usuario === null || usuario === void 0 ? void 0 : (ref = usuario.roles) === null || ref === void 0 ? void 0 : (ref2 = ref.some) === null || ref2 === void 0 ? void 0 : ref2.call(ref, (item)=>{
            return (item === null || item === void 0 ? void 0 : item.codigo) === rol;
        });
    };
    const activarOptionNavbarByPermiso = (permiso)=>{
        if (!tienePermiso(permiso)) {
            return {
                className: 'd-none',
                disabled: true
            };
        }
        return {
        };
    };
    return {
        isValidSession,
        setUsuario: (data)=>{
            localStorage.setItem('usuario', JSON.stringify(data));
        },
        usuario,
        tienePermiso,
        tieneRol,
        activarOptionNavbarByPermiso
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useUsuario);


/***/ })

};
;