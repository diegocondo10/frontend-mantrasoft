"use strict";
(() => {
var exports = {};
exports.id = 449;
exports.ids = [449];
exports.modules = {

/***/ 417:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8663);
/* harmony import */ var _src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3633);
/* harmony import */ var _src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5817);
/* harmony import */ var _src_constants_paises__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8552);
/* harmony import */ var _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(470);
/* harmony import */ var _src_hooks_useToasts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6181);
/* harmony import */ var _src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1630);
/* harmony import */ var _src_services_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8469);
/* harmony import */ var _src_services_urls__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6102);
/* harmony import */ var _src_utils_date__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3049);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_dist_client_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(387);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2250);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(primereact_api__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var primereact_calendar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7757);
/* harmony import */ var primereact_calendar__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(primereact_calendar__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1404);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9093);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5641);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_18__, _src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_18__, _src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




















const CreatePersonaPage = ({ crudAction , id  })=>{
    const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_18__.useForm)({
        mode: 'onChange'
    });
    const router = (0,next_dist_client_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { addErrorToast  } = (0,_src_hooks_useToasts__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const query = (0,react_query__WEBPACK_IMPORTED_MODULE_19__.useQuery)([
        'persona',
        crudAction,
        id
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_8__/* ["default"]["private"] */ .Z["private"]().get((0,_src_services_urls__WEBPACK_IMPORTED_MODULE_9__/* .urlDetailPersona */ .BM)(id))
    , {
        enabled: crudAction === _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.UPDATE */ .M.UPDATE,
        onSuccess: (data)=>{
            methods.reset(data === null || data === void 0 ? void 0 : data.data);
        },
        onError: ()=>{
            addErrorToast('No se ha podido encontrar el registro');
            router.push('/medicamentos');
        }
    });
    const queryCatalogo = (0,react_query__WEBPACK_IMPORTED_MODULE_19__.useQuery)([
        'catalogo-create'
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_8__/* ["default"]["private"] */ .Z["private"]().get(_src_services_urls__WEBPACK_IMPORTED_MODULE_9__/* .urlCatalogoCreate */ .ao)
    , {
        enabled: crudAction === _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.CREATE */ .M.CREATE
    });
    const updateMutation = (0,react_query__WEBPACK_IMPORTED_MODULE_19__.useMutation)((formData)=>_src_services_api__WEBPACK_IMPORTED_MODULE_8__/* ["default"]["private"] */ .Z["private"]().put((0,_src_services_urls__WEBPACK_IMPORTED_MODULE_9__/* .urlUpdatePersona */ .LF)(id), formData)
    );
    const createMutation = (0,react_query__WEBPACK_IMPORTED_MODULE_19__.useMutation)((formData)=>_src_services_api__WEBPACK_IMPORTED_MODULE_8__/* ["default"]["private"] */ .Z["private"]().post(_src_services_urls__WEBPACK_IMPORTED_MODULE_9__/* .urlCreatePersona */ .sT, formData)
    );
    const _onSubmit = async (formData)=>{
        let res = null;
        const Data = {
            ...formData,
            fechaNacimiento: (0,_src_utils_date__WEBPACK_IMPORTED_MODULE_10__/* .formatearFechaBackend */ .j)(formData.fechaNacimiento)
        };
        try {
            if (_src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.CREATE */ .M.CREATE === crudAction) {
                res = await createMutation.mutateAsync(Data);
            } else if (_src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.UPDATE */ .M.UPDATE === crudAction) {
                res = await updateMutation.mutateAsync(Data);
            }
            if (res.status === 201 || res.status === 200) {
                router.push('/personas');
            }
        } catch (error) {
            console.log(error);
            methods.reset(formData);
            alert('Ha ocurrido un problema al guardar la informaci\xf3n');
        }
    };
    console.log(queryCatalogo);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.FormProvider, {
        ...methods,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            loading: {
                loading: query.isLoading || createMutation.isLoading || updateMutation.isLoading
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "container-fluid",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "d-flex flex-row my-3 justify-content-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "align-self-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    href: "/personas",
                                    sm: true,
                                    rounded: true,
                                    icon: primereact_api__WEBPACK_IMPORTED_MODULE_13__.PrimeIcons.ARROW_LEFT,
                                    outlined: true
                                })
                            }),
                            _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.CREATE */ .M.CREATE === crudAction && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center align-self-center",
                                children: "Registro de informaci\xf3n"
                            }),
                            _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.UPDATE */ .M.UPDATE === crudAction && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center align-self-center",
                                children: "Editar informaci\xf3n"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row justify-content-center mb-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-11 border mb-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-11 mb-5",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        onSubmit: methods.handleSubmit(_onSubmit),
                                        className: "row mb-5",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "tipoIdentificacion",
                                                        children: "Tipo de identificaci\xf3n: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "tipoIdentificacion",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__.Dropdown, {
                                                                inputId: "tipoIdentificacion",
                                                                options: [
                                                                    'CEDULA',
                                                                    'PASAPORTE',
                                                                    'OTRO'
                                                                ],
                                                                ...field,
                                                                showClear: true,
                                                                placeholder: "Seleccione",
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "tipoIdentificacion"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Identificaci\xf3n: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "identificacion",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "identificacion",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "identificacion"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Primer Nombre: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "primerNombre",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "primerNombre",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "primerNombre"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Segundo Nombre: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "segundoNombre",
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "segundoNombre",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "segundoNombre"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Primer Apellido: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "primerApellido",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "primerApellido",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "primerApellido"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Segundo Apellido: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "segundoApellido",
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "segundoApellido",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "segundoApellido"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Fecha de Nacimiento: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "fechaNacimiento",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_calendar__WEBPACK_IMPORTED_MODULE_14__.Calendar, {
                                                                id: "fechaNacimiento",
                                                                dateFormat: "dd/mm/yy",
                                                                monthNavigator: true,
                                                                yearNavigator: true,
                                                                yearRange: "1930:2030",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "fechaNacimiento"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Celular: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "celular",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "celular",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "celular"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Tel\xe9fono: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "telefono",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "telefono",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "telefono"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Correo: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "correo",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "correo",
                                                                type: "email",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "correo"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "estadoCivil",
                                                        children: "Estado Civil: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "estadoCivil",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__.Dropdown, {
                                                                inputId: "estadoCivil",
                                                                options: [
                                                                    'SOLTERO',
                                                                    'CASADO',
                                                                    'DIVORCIADO',
                                                                    'VIUDO',
                                                                    'UNION LIBRE'
                                                                ],
                                                                ...field,
                                                                showClear: true,
                                                                placeholder: "Seleccione",
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "estadoCivil"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "genero",
                                                        children: "G\xe9nero: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "genero",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__.Dropdown, {
                                                                inputId: "genero",
                                                                options: [
                                                                    'MASCULINO',
                                                                    'FEMENINO'
                                                                ],
                                                                ...field,
                                                                showClear: true,
                                                                placeholder: "Seleccione",
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "genero"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "sexo",
                                                        children: "Sexo: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "genero",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__.Dropdown, {
                                                                inputId: "sexo",
                                                                options: [
                                                                    'HOMBRE',
                                                                    'MUJER',
                                                                    'OTRO'
                                                                ],
                                                                ...field,
                                                                showClear: true,
                                                                placeholder: "Seleccione",
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "sexo"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "pais",
                                                        children: "Pa\xeds: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "pais",
                                                        render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__.Dropdown, {
                                                                inputId: "pais",
                                                                options: _src_constants_paises__WEBPACK_IMPORTED_MODULE_4__/* .PAISES */ .j,
                                                                ...field,
                                                                showClear: true,
                                                                filter: true,
                                                                filterMatchMode: "contains",
                                                                placeholder: "Seleccione",
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full')
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "pais"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Calle Principal: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "callePrincipal",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "callePrincipal",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "callePrincipal"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "N\xfamero de casa:"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "numeroCasa",
                                                        render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "NumeroCasa",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full')
                                                            })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Calle Secundaria: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "calleSecundaria",
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "calleSecundaria",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "calleSecundaria"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Referencia:"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "referencia",
                                                        render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "referencia",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full')
                                                            })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-md-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Sector:"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                        name: "sector",
                                                        render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_16__.InputText, {
                                                                id: "sector",
                                                                ...field,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full')
                                                            })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                className: "my-5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-12",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "row",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-md-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "sexo",
                                                                    children: "Tipo de Sangre: *"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                                    name: "tipoSangre",
                                                                    render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_15__.Dropdown, {
                                                                            inputId: "tipoSangre",
                                                                            options: [
                                                                                'A+',
                                                                                'A-',
                                                                                'B+',
                                                                                'B-',
                                                                                'O+',
                                                                                'O-',
                                                                                'AB+',
                                                                                'AB-'
                                                                            ],
                                                                            ...field,
                                                                            showClear: true,
                                                                            placeholder: "Seleccione",
                                                                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()('w-full')
                                                                        })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-md-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "tieneIess",
                                                                    className: "w-full",
                                                                    children: "Tiene seguro de IESS?"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                                    name: "tieneIess",
                                                                    size: "lg"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-md-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "tieneHipertencion",
                                                                    className: "w-full",
                                                                    children: "Tiene Hipertenci\xf3n?"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                                    name: "tieneHipertencion",
                                                                    size: "lg"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-md-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    htmlFor: "tieneDiabetes",
                                                                    className: "w-full",
                                                                    children: "Tiene diabetes?"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                                    name: "tieneDiabetes",
                                                                    size: "lg"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            crudAction === _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_5__/* .CrudActions.CREATE */ .M.CREATE && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_17___default().Fragment), {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        className: "my-5"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-12",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "usuario.generar",
                                                                className: "w-full",
                                                                children: "Generar un usuario?"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_Toggle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                                name: "usuario.generar",
                                                                size: "lg",
                                                                defaultValue: false
                                                            })
                                                        ]
                                                    }),
                                                    methods.watch('usuario.generar') && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_17___default().Fragment), {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-md-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                    className: "w-full",
                                                                    children: "Seleccione el rol para el usuario:"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    name: "usuario.rol"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_18__.Controller, {
                                                                    name: "usuario.rol",
                                                                    rules: {
                                                                        required: 'Es necesario seleccionar un rol!'
                                                                    },
                                                                    render: ({ field  })=>{
                                                                        var ref, ref1, ref2;
                                                                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_17___default().Fragment), {
                                                                            children: queryCatalogo === null || queryCatalogo === void 0 ? void 0 : (ref = queryCatalogo.data) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.roles) === null || ref2 === void 0 ? void 0 : ref2.map((rol)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "w-full",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                            type: "radio",
                                                                                            name: "usuario.rol",
                                                                                            id: rol.value,
                                                                                            checked: field.value === rol.value,
                                                                                            onChange: ()=>field.onChange(rol.value)
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                            className: "font-bold",
                                                                                            htmlFor: rol.value,
                                                                                            children: rol.label
                                                                                        })
                                                                                    ]
                                                                                }, rol.value)
                                                                            )
                                                                        }));
                                                                    }
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row mt-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "row",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "col-md-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                    label: "Regresar",
                                                                    block: true,
                                                                    href: "/personas",
                                                                    variant: "info"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "col-md-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                    label: "Guardar",
                                                                    block: true,
                                                                    type: "submit"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
};
CreatePersonaPage.getInitialProps = ({ query  })=>query
;
CreatePersonaPage.help = {
    title: 'Formulario de registro de datos de personas dentro del sistema',
    content: 'Formulario de ingreso de datos de personas'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreatePersonaPage);

});

/***/ }),

/***/ 5817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_toggle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7288);
/* harmony import */ var react_bootstrap_toggle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_toggle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const Toggle = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
        name: props.name,
        rules: props.rules,
        defaultValue: props.defaultValue,
        render: ({ field  })=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_toggle__WEBPACK_IMPORTED_MODULE_2___default()), {
                onClick: field.onChange,
                on: (props === null || props === void 0 ? void 0 : props.on) || 'SI',
                off: (props === null || props === void 0 ? void 0 : props.on) || 'NO',
                size: props.size || 'lg',
                handleClassName: "bg-white",
                offstyle: props.offstyle || 'dark',
                onstyle: props.offstyle || 'primary',
                active: field.value
            }));
        }
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Toggle);

});

/***/ }),

/***/ 8552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ PAISES)
/* harmony export */ });
const PAISES = [
    {
        label: 'AFGHANISTAN',
        value: 'AFGHANISTAN'
    },
    {
        label: 'ALBANIA',
        value: 'ALBANIA'
    },
    {
        label: 'ALGERIA',
        value: 'ALGERIA'
    },
    {
        label: 'AMERICAN SAMOA',
        value: 'AMERICAN SAMOA'
    },
    {
        label: 'ANDORRA',
        value: 'ANDORRA'
    },
    {
        label: 'ANGOLA',
        value: 'ANGOLA'
    },
    {
        label: 'ANGUILLA',
        value: 'ANGUILLA'
    },
    {
        label: 'ANTARCTICA',
        value: 'ANTARCTICA'
    },
    {
        label: 'ANTIGUA AND BARBUDA',
        value: 'ANTIGUA AND BARBUDA'
    },
    {
        label: 'ARGENTINA',
        value: 'ARGENTINA'
    },
    {
        label: 'ARMENIA',
        value: 'ARMENIA'
    },
    {
        label: 'ARUBA',
        value: 'ARUBA'
    },
    {
        label: 'AUSTRALIA',
        value: 'AUSTRALIA'
    },
    {
        label: 'AUSTRIA',
        value: 'AUSTRIA'
    },
    {
        label: 'AZERBAIJAN',
        value: 'AZERBAIJAN'
    },
    {
        label: 'BAHAMAS',
        value: 'BAHAMAS'
    },
    {
        label: 'BAHRAIN',
        value: 'BAHRAIN'
    },
    {
        label: 'BANGLADESH',
        value: 'BANGLADESH'
    },
    {
        label: 'BARBADOS',
        value: 'BARBADOS'
    },
    {
        label: 'BELARUS',
        value: 'BELARUS'
    },
    {
        label: 'BELGIUM',
        value: 'BELGIUM'
    },
    {
        label: 'BELIZE',
        value: 'BELIZE'
    },
    {
        label: 'BENIN',
        value: 'BENIN'
    },
    {
        label: 'BERMUDA',
        value: 'BERMUDA'
    },
    {
        label: 'BHUTAN',
        value: 'BHUTAN'
    },
    {
        label: 'BOLIVIA',
        value: 'BOLIVIA'
    },
    {
        label: 'BOSNIA AND HERZEGOVINA',
        value: 'BOSNIA AND HERZEGOVINA'
    },
    {
        label: 'BOTSWANA',
        value: 'BOTSWANA'
    },
    {
        label: 'BOUVET ISLAND',
        value: 'BOUVET ISLAND'
    },
    {
        label: 'BRAZIL',
        value: 'BRAZIL'
    },
    {
        label: 'BRITISH INDIAN OCEAN TERRITORY',
        value: 'BRITISH INDIAN OCEAN TERRITORY'
    },
    {
        label: 'BRUNEI',
        value: 'BRUNEI'
    },
    {
        label: 'BULGARIA',
        value: 'BULGARIA'
    },
    {
        label: 'BURKINA FASO',
        value: 'BURKINA FASO'
    },
    {
        label: 'BURUNDI',
        value: 'BURUNDI'
    },
    {
        label: 'CAMBODIA',
        value: 'CAMBODIA'
    },
    {
        label: 'CAMEROON',
        value: 'CAMEROON'
    },
    {
        label: 'CANADA',
        value: 'CANADA'
    },
    {
        label: 'CAPE VERDE',
        value: 'CAPE VERDE'
    },
    {
        label: 'CAYMAN ISLANDS',
        value: 'CAYMAN ISLANDS'
    },
    {
        label: 'CENTRAL AFRICAN REPUBLIC',
        value: 'CENTRAL AFRICAN REPUBLIC'
    },
    {
        label: 'CHAD',
        value: 'CHAD'
    },
    {
        label: 'CHILE',
        value: 'CHILE'
    },
    {
        label: 'CHINA',
        value: 'CHINA'
    },
    {
        label: 'CHRISTMAS ISLAND',
        value: 'CHRISTMAS ISLAND'
    },
    {
        label: 'COCOS (KEELING) ISLANDS',
        value: 'COCOS (KEELING) ISLANDS'
    },
    {
        label: 'COLOMBIA',
        value: 'COLOMBIA'
    },
    {
        label: 'COMOROS',
        value: 'COMOROS'
    },
    {
        label: 'CONGO',
        value: 'CONGO'
    },
    {
        label: 'CONGO, THE DEMOCRATIC REPUBLIC OF THE',
        value: 'CONGO, THE DEMOCRATIC REPUBLIC OF THE'
    },
    {
        label: 'COOK ISLANDS',
        value: 'COOK ISLANDS'
    },
    {
        label: 'COSTA RICA',
        value: 'COSTA RICA'
    },
    {
        label: 'C\xd4TE D’IVOIRE',
        value: 'C\xd4TE D’IVOIRE'
    },
    {
        label: 'CROATIA',
        value: 'CROATIA'
    },
    {
        label: 'CUBA',
        value: 'CUBA'
    },
    {
        label: 'CYPRUS',
        value: 'CYPRUS'
    },
    {
        label: 'CZECH REPUBLIC',
        value: 'CZECH REPUBLIC'
    },
    {
        label: 'DENMARK',
        value: 'DENMARK'
    },
    {
        label: 'DJIBOUTI',
        value: 'DJIBOUTI'
    },
    {
        label: 'DOMINICA',
        value: 'DOMINICA'
    },
    {
        label: 'DOMINICAN REPUBLIC',
        value: 'DOMINICAN REPUBLIC'
    },
    {
        label: 'EAST TIMOR',
        value: 'EAST TIMOR'
    },
    {
        label: 'ECUADOR',
        value: 'ECUADOR'
    },
    {
        label: 'EGYPT',
        value: 'EGYPT'
    },
    {
        label: 'EL SALVADOR',
        value: 'EL SALVADOR'
    },
    {
        label: 'EQUATORIAL GUINEA',
        value: 'EQUATORIAL GUINEA'
    },
    {
        label: 'ERITREA',
        value: 'ERITREA'
    },
    {
        label: 'ESTONIA',
        value: 'ESTONIA'
    },
    {
        label: 'ETHIOPIA',
        value: 'ETHIOPIA'
    },
    {
        label: 'FALKLAND ISLANDS',
        value: 'FALKLAND ISLANDS'
    },
    {
        label: 'FAROE ISLANDS',
        value: 'FAROE ISLANDS'
    },
    {
        label: 'FIJI ISLANDS',
        value: 'FIJI ISLANDS'
    },
    {
        label: 'FINLAND',
        value: 'FINLAND'
    },
    {
        label: 'FRANCE',
        value: 'FRANCE'
    },
    {
        label: 'FRENCH GUIANA',
        value: 'FRENCH GUIANA'
    },
    {
        label: 'FRENCH POLYNESIA',
        value: 'FRENCH POLYNESIA'
    },
    {
        label: 'FRENCH SOUTHERN TERRITORIES',
        value: 'FRENCH SOUTHERN TERRITORIES'
    },
    {
        label: 'GABON',
        value: 'GABON'
    },
    {
        label: 'GAMBIA',
        value: 'GAMBIA'
    },
    {
        label: 'GEORGIA',
        value: 'GEORGIA'
    },
    {
        label: 'GERMANY',
        value: 'GERMANY'
    },
    {
        label: 'GHANA',
        value: 'GHANA'
    },
    {
        label: 'GIBRALTAR',
        value: 'GIBRALTAR'
    },
    {
        label: 'GREECE',
        value: 'GREECE'
    },
    {
        label: 'GREENLAND',
        value: 'GREENLAND'
    },
    {
        label: 'GRENADA',
        value: 'GRENADA'
    },
    {
        label: 'GUADELOUPE',
        value: 'GUADELOUPE'
    },
    {
        label: 'GUAM',
        value: 'GUAM'
    },
    {
        label: 'GUATEMALA',
        value: 'GUATEMALA'
    },
    {
        label: 'GUINEA',
        value: 'GUINEA'
    },
    {
        label: 'GUINEA-BISSAU',
        value: 'GUINEA-BISSAU'
    },
    {
        label: 'GUYANA',
        value: 'GUYANA'
    },
    {
        label: 'HAITI',
        value: 'HAITI'
    },
    {
        label: 'HEARD ISLAND AND MCDONALD ISLANDS',
        value: 'HEARD ISLAND AND MCDONALD ISLANDS'
    },
    {
        label: 'HOLY SEE (VATICAN CITY STATE)',
        value: 'HOLY SEE (VATICAN CITY STATE)'
    },
    {
        label: 'HONDURAS',
        value: 'HONDURAS'
    },
    {
        label: 'HONG KONG',
        value: 'HONG KONG'
    },
    {
        label: 'HUNGARY',
        value: 'HUNGARY'
    },
    {
        label: 'ICELAND',
        value: 'ICELAND'
    },
    {
        label: 'INDIA',
        value: 'INDIA'
    },
    {
        label: 'INDONESIA',
        value: 'INDONESIA'
    },
    {
        label: 'IRAN',
        value: 'IRAN'
    },
    {
        label: 'IRAQ',
        value: 'IRAQ'
    },
    {
        label: 'IRELAND',
        value: 'IRELAND'
    },
    {
        label: 'ISRAEL',
        value: 'ISRAEL'
    },
    {
        label: 'ITALY',
        value: 'ITALY'
    },
    {
        label: 'JAMAICA',
        value: 'JAMAICA'
    },
    {
        label: 'JAPAN',
        value: 'JAPAN'
    },
    {
        label: 'JORDAN',
        value: 'JORDAN'
    },
    {
        label: 'KAZAKSTAN',
        value: 'KAZAKSTAN'
    },
    {
        label: 'KENYA',
        value: 'KENYA'
    },
    {
        label: 'KIRIBATI',
        value: 'KIRIBATI'
    },
    {
        label: 'KUWAIT',
        value: 'KUWAIT'
    },
    {
        label: 'KYRGYZSTAN',
        value: 'KYRGYZSTAN'
    },
    {
        label: 'LAOS',
        value: 'LAOS'
    },
    {
        label: 'LATVIA',
        value: 'LATVIA'
    },
    {
        label: 'LEBANON',
        value: 'LEBANON'
    },
    {
        label: 'LESOTHO',
        value: 'LESOTHO'
    },
    {
        label: 'LIBERIA',
        value: 'LIBERIA'
    },
    {
        label: 'LIBYAN ARAB JAMAHIRIYA',
        value: 'LIBYAN ARAB JAMAHIRIYA'
    },
    {
        label: 'LIECHTENSTEIN',
        value: 'LIECHTENSTEIN'
    },
    {
        label: 'LITHUANIA',
        value: 'LITHUANIA'
    },
    {
        label: 'LUXEMBOURG',
        value: 'LUXEMBOURG'
    },
    {
        label: 'MACAO',
        value: 'MACAO'
    },
    {
        label: 'MACEDONIA',
        value: 'MACEDONIA'
    },
    {
        label: 'MADAGASCAR',
        value: 'MADAGASCAR'
    },
    {
        label: 'MALAWI',
        value: 'MALAWI'
    },
    {
        label: 'MALAYSIA',
        value: 'MALAYSIA'
    },
    {
        label: 'MALDIVES',
        value: 'MALDIVES'
    },
    {
        label: 'MALI',
        value: 'MALI'
    },
    {
        label: 'MALTA',
        value: 'MALTA'
    },
    {
        label: 'MARSHALL ISLANDS',
        value: 'MARSHALL ISLANDS'
    },
    {
        label: 'MARTINIQUE',
        value: 'MARTINIQUE'
    },
    {
        label: 'MAURITANIA',
        value: 'MAURITANIA'
    },
    {
        label: 'MAURITIUS',
        value: 'MAURITIUS'
    },
    {
        label: 'MAYOTTE',
        value: 'MAYOTTE'
    },
    {
        label: 'MEXICO',
        value: 'MEXICO'
    },
    {
        label: 'MICRONESIA, FEDERATED STATES OF',
        value: 'MICRONESIA, FEDERATED STATES OF'
    },
    {
        label: 'MOLDOVA',
        value: 'MOLDOVA'
    },
    {
        label: 'MONACO',
        value: 'MONACO'
    },
    {
        label: 'MONGOLIA',
        value: 'MONGOLIA'
    },
    {
        label: 'MONTSERRAT',
        value: 'MONTSERRAT'
    },
    {
        label: 'MOROCCO',
        value: 'MOROCCO'
    },
    {
        label: 'MOZAMBIQUE',
        value: 'MOZAMBIQUE'
    },
    {
        label: 'MYANMAR',
        value: 'MYANMAR'
    },
    {
        label: 'NAMIBIA',
        value: 'NAMIBIA'
    },
    {
        label: 'NAURU',
        value: 'NAURU'
    },
    {
        label: 'NEPAL',
        value: 'NEPAL'
    },
    {
        label: 'NETHERLANDS',
        value: 'NETHERLANDS'
    },
    {
        label: 'NETHERLANDS ANTILLES',
        value: 'NETHERLANDS ANTILLES'
    },
    {
        label: 'NEW CALEDONIA',
        value: 'NEW CALEDONIA'
    },
    {
        label: 'NEW ZEALAND',
        value: 'NEW ZEALAND'
    },
    {
        label: 'NICARAGUA',
        value: 'NICARAGUA'
    },
    {
        label: 'NIGER',
        value: 'NIGER'
    },
    {
        label: 'NIGERIA',
        value: 'NIGERIA'
    },
    {
        label: 'NIUE',
        value: 'NIUE'
    },
    {
        label: 'NORFOLK ISLAND',
        value: 'NORFOLK ISLAND'
    },
    {
        label: 'NORTHERN MARIANA ISLANDS',
        value: 'NORTHERN MARIANA ISLANDS'
    },
    {
        label: 'NORTH KOREA',
        value: 'NORTH KOREA'
    },
    {
        label: 'NORWAY',
        value: 'NORWAY'
    },
    {
        label: 'OMAN',
        value: 'OMAN'
    },
    {
        label: 'PAKISTAN',
        value: 'PAKISTAN'
    },
    {
        label: 'PALAU',
        value: 'PALAU'
    },
    {
        label: 'PALESTINE',
        value: 'PALESTINE'
    },
    {
        label: 'PANAMA',
        value: 'PANAMA'
    },
    {
        label: 'PAPUA NEW GUINEA',
        value: 'PAPUA NEW GUINEA'
    },
    {
        label: 'PARAGUAY',
        value: 'PARAGUAY'
    },
    {
        label: 'PERU',
        value: 'PERU'
    },
    {
        label: 'PHILIPPINES',
        value: 'PHILIPPINES'
    },
    {
        label: 'PITCAIRN',
        value: 'PITCAIRN'
    },
    {
        label: 'POLAND',
        value: 'POLAND'
    },
    {
        label: 'PORTUGAL',
        value: 'PORTUGAL'
    },
    {
        label: 'PUERTO RICO',
        value: 'PUERTO RICO'
    },
    {
        label: 'QATAR',
        value: 'QATAR'
    },
    {
        label: 'R\xc9UNION',
        value: 'R\xc9UNION'
    },
    {
        label: 'ROMANIA',
        value: 'ROMANIA'
    },
    {
        label: 'RUSSIAN FEDERATION',
        value: 'RUSSIAN FEDERATION'
    },
    {
        label: 'RWANDA',
        value: 'RWANDA'
    },
    {
        label: 'SAINT HELENA',
        value: 'SAINT HELENA'
    },
    {
        label: 'SAINT KITTS AND NEVIS',
        value: 'SAINT KITTS AND NEVIS'
    },
    {
        label: 'SAINT LUCIA',
        value: 'SAINT LUCIA'
    },
    {
        label: 'SAINT PIERRE AND MIQUELON',
        value: 'SAINT PIERRE AND MIQUELON'
    },
    {
        label: 'SAINT VINCENT AND THE GRENADINES',
        value: 'SAINT VINCENT AND THE GRENADINES'
    },
    {
        label: 'SAMOA',
        value: 'SAMOA'
    },
    {
        label: 'SAN MARINO',
        value: 'SAN MARINO'
    },
    {
        label: 'SAO TOME AND PRINCIPE',
        value: 'SAO TOME AND PRINCIPE'
    },
    {
        label: 'SAUDI ARABIA',
        value: 'SAUDI ARABIA'
    },
    {
        label: 'SENEGAL',
        value: 'SENEGAL'
    },
    {
        label: 'SEYCHELLES',
        value: 'SEYCHELLES'
    },
    {
        label: 'SIERRA LEONE',
        value: 'SIERRA LEONE'
    },
    {
        label: 'SINGAPORE',
        value: 'SINGAPORE'
    },
    {
        label: 'SLOVAKIA',
        value: 'SLOVAKIA'
    },
    {
        label: 'SLOVENIA',
        value: 'SLOVENIA'
    },
    {
        label: 'SOLOMON ISLANDS',
        value: 'SOLOMON ISLANDS'
    },
    {
        label: 'SOMALIA',
        value: 'SOMALIA'
    },
    {
        label: 'SOUTH AFRICA',
        value: 'SOUTH AFRICA'
    },
    {
        label: 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS',
        value: 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS'
    },
    {
        label: 'SOUTH KOREA',
        value: 'SOUTH KOREA'
    },
    {
        label: 'SPAIN',
        value: 'SPAIN'
    },
    {
        label: 'SRI LANKA',
        value: 'SRI LANKA'
    },
    {
        label: 'SUDAN',
        value: 'SUDAN'
    },
    {
        label: 'SURINAME',
        value: 'SURINAME'
    },
    {
        label: 'SVALBARD AND JAN MAYEN',
        value: 'SVALBARD AND JAN MAYEN'
    },
    {
        label: 'SWAZILAND',
        value: 'SWAZILAND'
    },
    {
        label: 'SWEDEN',
        value: 'SWEDEN'
    },
    {
        label: 'SWITZERLAND',
        value: 'SWITZERLAND'
    },
    {
        label: 'SYRIA',
        value: 'SYRIA'
    },
    {
        label: 'TAIWAN',
        value: 'TAIWAN'
    },
    {
        label: 'TAJIKISTAN',
        value: 'TAJIKISTAN'
    },
    {
        label: 'TANZANIA',
        value: 'TANZANIA'
    },
    {
        label: 'THAILAND',
        value: 'THAILAND'
    },
    {
        label: 'TOGO',
        value: 'TOGO'
    },
    {
        label: 'TOKELAU',
        value: 'TOKELAU'
    },
    {
        label: 'TONGA',
        value: 'TONGA'
    },
    {
        label: 'TRINIDAD AND TOBAGO',
        value: 'TRINIDAD AND TOBAGO'
    },
    {
        label: 'TUNISIA',
        value: 'TUNISIA'
    },
    {
        label: 'TURKEY',
        value: 'TURKEY'
    },
    {
        label: 'TURKMENISTAN',
        value: 'TURKMENISTAN'
    },
    {
        label: 'TURKS AND CAICOS ISLANDS',
        value: 'TURKS AND CAICOS ISLANDS'
    },
    {
        label: 'TUVALU',
        value: 'TUVALU'
    },
    {
        label: 'UGANDA',
        value: 'UGANDA'
    },
    {
        label: 'UKRAINE',
        value: 'UKRAINE'
    },
    {
        label: 'UNITED ARAB EMIRATES',
        value: 'UNITED ARAB EMIRATES'
    },
    {
        label: 'UNITED KINGDOM',
        value: 'UNITED KINGDOM'
    },
    {
        label: 'UNITED STATES',
        value: 'UNITED STATES'
    },
    {
        label: 'UNITED STATES MINOR OUTLYING ISLANDS',
        value: 'UNITED STATES MINOR OUTLYING ISLANDS'
    },
    {
        label: 'URUGUAY',
        value: 'URUGUAY'
    },
    {
        label: 'UZBEKISTAN',
        value: 'UZBEKISTAN'
    },
    {
        label: 'VANUATU',
        value: 'VANUATU'
    },
    {
        label: 'VENEZUELA',
        value: 'VENEZUELA'
    },
    {
        label: 'VIETNAM',
        value: 'VIETNAM'
    },
    {
        label: 'VIRGIN ISLANDS, BRITISH',
        value: 'VIRGIN ISLANDS, BRITISH'
    },
    {
        label: 'VIRGIN ISLANDS, U.S.',
        value: 'VIRGIN ISLANDS, U.S.'
    },
    {
        label: 'WALLIS AND FUTUNA',
        value: 'WALLIS AND FUTUNA'
    },
    {
        label: 'WESTERN SAHARA',
        value: 'WESTERN SAHARA'
    },
    {
        label: 'YEMEN',
        value: 'YEMEN'
    },
    {
        label: 'YUGOSLAVIA',
        value: 'YUGOSLAVIA'
    },
    {
        label: 'ZAMBIA',
        value: 'ZAMBIA'
    },
    {
        label: 'ZIMBABWE',
        value: 'ZIMBABWE'
    }, 
];


/***/ }),

/***/ 470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ CrudActions1)
/* harmony export */ });
var CrudActions1;

(function(CrudActions) {
    CrudActions["CREATE"] = 'create';
    CrudActions["UPDATE"] = 'editar';
    CrudActions["DELETE"] = 'eliminar';
    CrudActions["DETAIL"] = 'detalle';
})(CrudActions1 || (CrudActions1 = {
}));


/***/ }),

/***/ 3218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 2250:
/***/ ((module) => {

module.exports = require("primereact/api");

/***/ }),

/***/ 1088:
/***/ ((module) => {

module.exports = require("primereact/button");

/***/ }),

/***/ 7757:
/***/ ((module) => {

module.exports = require("primereact/calendar");

/***/ }),

/***/ 1404:
/***/ ((module) => {

module.exports = require("primereact/dropdown");

/***/ }),

/***/ 9093:
/***/ ((module) => {

module.exports = require("primereact/inputtext");

/***/ }),

/***/ 4130:
/***/ ((module) => {

module.exports = require("primereact/menubar");

/***/ }),

/***/ 5767:
/***/ ((module) => {

module.exports = require("primereact/progressspinner");

/***/ }),

/***/ 8345:
/***/ ((module) => {

module.exports = require("primereact/scrolltop");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 7288:
/***/ ((module) => {

module.exports = require("react-bootstrap-toggle");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 5927:
/***/ ((module) => {

module.exports = require("react-toast-notifications");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,285,253,663,469,630,24,49], () => (__webpack_exec__(417)));
module.exports = __webpack_exports__;

})();