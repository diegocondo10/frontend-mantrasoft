"use strict";
(() => {
var exports = {};
exports.id = 435;
exports.ids = [435];
exports.modules = {

/***/ 3269:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8663);
/* harmony import */ var _src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3633);
/* harmony import */ var _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(470);
/* harmony import */ var _src_hooks_useToasts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6181);
/* harmony import */ var _src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1630);
/* harmony import */ var _src_services_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8469);
/* harmony import */ var _src_services_urls__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6102);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(387);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2250);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(primereact_api__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1404);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(primereact_dropdown__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9093);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtext__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6085);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5641);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_15__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_15__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

















const FormMedicamentosPage = ({ crudAction , id  })=>{
    const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_15__.useForm)({
        mode: 'onChange',
        shouldUnregister: true
    });
    const router = (0,next_dist_client_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { addErrorToast  } = (0,_src_hooks_useToasts__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const query = (0,react_query__WEBPACK_IMPORTED_MODULE_16__.useQuery)([
        'medicamento',
        crudAction,
        id
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_6__/* ["default"]["private"] */ .Z["private"]().get((0,_src_services_urls__WEBPACK_IMPORTED_MODULE_7__/* .urlDetailMedicamento */ .aP)(id))
    , {
        enabled: crudAction === _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_3__/* .CrudActions.UPDATE */ .M.UPDATE,
        onSuccess (data) {
            methods.reset(data === null || data === void 0 ? void 0 : data.data);
        },
        onError (err) {
            addErrorToast('No se ha podido encontrar el registro');
            router.push('/medicamentos');
        }
    });
    const updateMutation = (0,react_query__WEBPACK_IMPORTED_MODULE_16__.useMutation)((formData)=>_src_services_api__WEBPACK_IMPORTED_MODULE_6__/* ["default"]["private"] */ .Z["private"]().put((0,_src_services_urls__WEBPACK_IMPORTED_MODULE_7__/* .urlUpdateMedicamento */ .Ps)(id), formData)
    );
    const createMutation = (0,react_query__WEBPACK_IMPORTED_MODULE_16__.useMutation)((formData)=>_src_services_api__WEBPACK_IMPORTED_MODULE_6__/* ["default"]["private"] */ .Z["private"]().post(_src_services_urls__WEBPACK_IMPORTED_MODULE_7__/* .urlCreateMedicamento */ .FV, formData)
    );
    const _onSubmit = async (formData)=>{
        try {
            let res = null;
            if (_src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_3__/* .CrudActions.CREATE */ .M.CREATE === crudAction) {
                res = await createMutation.mutateAsync(formData);
            } else if (_src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_3__/* .CrudActions.UPDATE */ .M.UPDATE === crudAction) {
                res = await updateMutation.mutateAsync(formData);
            }
            if (res.status === 201 || res.status === 200) {
                router.push('/medicamentos');
            }
        } catch (error) {
            addErrorToast('Ha ocurrido un problema al guardar la informaci\xf3n');
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.FormProvider, {
        ...methods,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            loading: {
                loading: query.isLoading || createMutation.isLoading || updateMutation.isLoading
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "container-fluid",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "d-flex flex-row my-3 justify-content-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "align-self-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    href: "/medicamentos",
                                    sm: true,
                                    rounded: true,
                                    icon: primereact_api__WEBPACK_IMPORTED_MODULE_10__.PrimeIcons.ARROW_LEFT,
                                    outlined: true
                                })
                            }),
                            _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_3__/* .CrudActions.CREATE */ .M.CREATE === crudAction && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center align-self-center",
                                children: "Registro de informaci\xf3n"
                            }),
                            _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_3__/* .CrudActions.UPDATE */ .M.UPDATE === crudAction && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-center align-self-center",
                                children: "Editar informaci\xf3n"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-11 border",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-11",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        onSubmit: methods.handleSubmit(_onSubmit),
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-12",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "nombre",
                                                        children: "Nombre: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                                        name: "nombre",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_12__.InputText, {
                                                                id: "nombre",
                                                                ...field,
                                                                placeholder: "Nombre del medicamento",
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "nombre"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-12",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "via",
                                                        children: "Via: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                                        name: "via",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_11__.Dropdown, {
                                                                inputId: "via",
                                                                ...field,
                                                                placeholder: "Seleccione",
                                                                options: [
                                                                    'VO',
                                                                    'VR',
                                                                    'VI'
                                                                ],
                                                                showClear: true,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                }),
                                                                inputRef: field.ref
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "via"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-12",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "via",
                                                        children: "Variante: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                                        name: "variante",
                                                        rules: {
                                                            required: 'Este campo es obligatorio'
                                                        },
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_11__.Dropdown, {
                                                                inputId: "variante",
                                                                ...field,
                                                                placeholder: "Seleccione",
                                                                options: [
                                                                    'TABLETA',
                                                                    'GOTAS',
                                                                    'INYECTABLE'
                                                                ],
                                                                showClear: true,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                }),
                                                                inputRef: field.ref
                                                            })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        name: "variante"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-12",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "descripcion",
                                                        children: "Descripci\xf3n: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_15__.Controller, {
                                                        name: "descripcion",
                                                        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_13__.InputTextarea, {
                                                                id: "descripcion",
                                                                ...field,
                                                                autoResize: true,
                                                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('w-full', {
                                                                    'p-invalid': fieldState.invalid
                                                                })
                                                            })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row mt-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "row",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "col-md-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                    label: "Regresar",
                                                                    block: true,
                                                                    href: "/medicamentos",
                                                                    variant: "info"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "col-md-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                    label: "Guardar",
                                                                    block: true,
                                                                    type: "submit"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
};
FormMedicamentosPage.getInitialProps = ({ query  })=>query
;
FormMedicamentosPage.help = {
    title: 'Formulario de registros de datos de medicamentos',
    content: 'Formulario de ingreso de datos para medicamentos'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormMedicamentosPage);

});

/***/ }),

/***/ 470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ CrudActions1)
/* harmony export */ });
var CrudActions1;

(function(CrudActions) {
    CrudActions["CREATE"] = 'create';
    CrudActions["UPDATE"] = 'editar';
    CrudActions["DELETE"] = 'eliminar';
    CrudActions["DETAIL"] = 'detalle';
})(CrudActions1 || (CrudActions1 = {
}));


/***/ }),

/***/ 3218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 2250:
/***/ ((module) => {

module.exports = require("primereact/api");

/***/ }),

/***/ 1088:
/***/ ((module) => {

module.exports = require("primereact/button");

/***/ }),

/***/ 1404:
/***/ ((module) => {

module.exports = require("primereact/dropdown");

/***/ }),

/***/ 9093:
/***/ ((module) => {

module.exports = require("primereact/inputtext");

/***/ }),

/***/ 6085:
/***/ ((module) => {

module.exports = require("primereact/inputtextarea");

/***/ }),

/***/ 4130:
/***/ ((module) => {

module.exports = require("primereact/menubar");

/***/ }),

/***/ 5767:
/***/ ((module) => {

module.exports = require("primereact/progressspinner");

/***/ }),

/***/ 8345:
/***/ ((module) => {

module.exports = require("primereact/scrolltop");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 5927:
/***/ ((module) => {

module.exports = require("react-toast-notifications");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,285,253,663,469,630,24], () => (__webpack_exec__(3269)));
module.exports = __webpack_exports__;

})();