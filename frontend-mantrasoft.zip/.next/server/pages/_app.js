"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app),
  "queryClient": () => (/* binding */ queryClient)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "primereact/api"
var api_ = __webpack_require__(2250);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/components/Button.tsx
var Button = __webpack_require__(8663);
// EXTERNAL MODULE: ./src/components/Modal/index.tsx
var Modal = __webpack_require__(4311);
;// CONCATENATED MODULE: ./src/components/HelpButton/index.tsx





const HelpButton = (props)=>{
    const { 0: show , 1: setShow  } = (0,external_react_.useState)(false);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                className: "font-bold",
                rounded: true,
                outlined: true,
                onClick: ()=>setShow(true)
                ,
                style: {
                    bottom: 10,
                    left: 10,
                    position: 'absolute'
                },
                icon: api_.PrimeIcons.QUESTION
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Modal/* default */.Z, {
                show: show,
                onHide: ()=>setShow(false)
                ,
                header: {
                    title: props.title,
                    closeButton: true
                },
                children: [
                    typeof props.content === 'string' && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: props.content
                        }
                    }),
                    typeof props.content === 'object' && props.content
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_HelpButton = (HelpButton);

// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
;// CONCATENATED MODULE: external "moment/locale/es"
const es_namespaceObject = require("moment/locale/es");
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
;// CONCATENATED MODULE: external "react-sweet-state"
const external_react_sweet_state_namespaceObject = require("react-sweet-state");
// EXTERNAL MODULE: external "react-toast-notifications"
var external_react_toast_notifications_ = __webpack_require__(5927);
;// CONCATENATED MODULE: ./pages/_app.tsx










const setLocale = ()=>{
    (0,api_.addLocale)('es', {
        firstDayOfWeek: 1,
        dayNames: [
            'Domingo',
            'Lunes',
            'Martes',
            'Mi\xe9rcoles',
            'Jueves',
            'Viernes',
            'S\xe1bado'
        ],
        dayNamesShort: [
            'dom',
            'lun',
            'mar',
            'mi\xe9',
            'jue',
            'vie',
            's\xe1b'
        ],
        dayNamesMin: [
            'D',
            'L',
            'M',
            'X',
            'J',
            'V',
            'S'
        ],
        monthNames: [
            'Enero',
            'Febrero',
            'Marzo',
            'Abril',
            'Mayo',
            'Junio',
            'Julio',
            'Agosto',
            'Septiembre',
            'Octubre',
            'Noviembre',
            'Diciembre', 
        ],
        monthNamesShort: [
            'Ene',
            'Feb',
            'Mar',
            'Abr',
            'May',
            'Jun',
            'Jul',
            'Ago',
            'Sep',
            'Oct',
            'Nov',
            'Dic'
        ],
        today: 'Hoy',
        clear: 'Limpiar'
    });
    (0,api_.locale)('es');
    external_moment_default().locale('es');
};
const Hydratation = ({ children  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        suppressHydrationWarning: true,
        children:  true ? null : 0
    }));
};
const queryClient = new external_react_query_.QueryClient();
function MyApp({ Component , pageProps  }) {
    var ref, ref1;
    (0,external_react_.useEffect)(()=>{
        setLocale();
        external_react_sweet_state_namespaceObject.defaults.devtools = true;
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Hydratation, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_query_.QueryClientProvider, {
                client: queryClient,
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_toast_notifications_.ToastProvider, {
                    autoDismiss: true,
                    autoDismissTimeout: 10000,
                    placement: "top-left",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            }),
            (Component === null || Component === void 0 ? void 0 : Component.help) && /*#__PURE__*/ jsx_runtime_.jsx(components_HelpButton, {
                title: (ref = Component.help) === null || ref === void 0 ? void 0 : ref.title,
                content: Component === null || Component === void 0 ? void 0 : (ref1 = Component.help) === null || ref1 === void 0 ? void 0 : ref1.content
            })
        ]
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 2250:
/***/ ((module) => {

module.exports = require("primereact/api");

/***/ }),

/***/ 1088:
/***/ ((module) => {

module.exports = require("primereact/button");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9306:
/***/ ((module) => {

module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 5927:
/***/ ((module) => {

module.exports = require("react-toast-notifications");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,285,663,311], () => (__webpack_exec__(422)));
module.exports = __webpack_exports__;

})();