"use strict";
(() => {
var exports = {};
exports.id = 192;
exports.ids = [192];
exports.modules = {

/***/ 4371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8663);
/* harmony import */ var _src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1630);
/* harmony import */ var _src_services_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8469);
/* harmony import */ var _src_services_urls__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6102);
/* harmony import */ var _src_utils_date__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3049);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2250);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(primereact_api__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1404);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(primereact_dropdown__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var primereact_toolbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(603);
/* harmony import */ var primereact_toolbar__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(primereact_toolbar__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_11__);












const GeneracionHorarioPage = ({ startDate , endDate  })=>{
    var ref2, ref1;
    const fechas = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>(0,_src_utils_date__WEBPACK_IMPORTED_MODULE_5__/* .generarFechasEntre */ .$v)(moment__WEBPACK_IMPORTED_MODULE_6___default()(startDate), moment__WEBPACK_IMPORTED_MODULE_6___default()(endDate))
    , [
        startDate,
        endDate
    ]);
    const { 0: filas , 1: setFilas  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const query = (0,react_query__WEBPACK_IMPORTED_MODULE_11__.useQuery)([
        'parametros',
        endDate,
        startDate
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_3__/* ["default"]["private"] */ .Z["private"]().get(_src_services_urls__WEBPACK_IMPORTED_MODULE_4__/* .urlParametrosGeneracionHorario */ .Ib)
    );
    const queryHorarios = (0,react_query__WEBPACK_IMPORTED_MODULE_11__.useQuery)([
        'horarios',
        startDate,
        endDate
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_3__/* ["default"]["private"] */ .Z["private"]().get((0,_src_services_urls__WEBPACK_IMPORTED_MODULE_4__/* .urlConsultarHorarios */ .Vz)(startDate, endDate))
    , {
        onSuccess: ({ data  })=>{
            const items = [
                ...data
            ];
            const newData = data === null || data === void 0 ? void 0 : data.map((item, index)=>{
                var ref4;
                return {
                    ...item,
                    dias: (ref4 = Object.values(fechas).map((fecha)=>fecha.dias
                    ).flat()) === null || ref4 === void 0 ? void 0 : ref4.map((dia)=>{
                        var ref, ref3;
                        const diaOriginal = (ref = items[index]) === null || ref === void 0 ? void 0 : ref.dias.find((obj)=>{
                            return obj.fecha == (dia === null || dia === void 0 ? void 0 : dia.date);
                        });
                        return {
                            ...diaOriginal,
                            ...dia,
                            jornada: (ref3 = getJornada(diaOriginal === null || diaOriginal === void 0 ? void 0 : diaOriginal.jornada)) === null || ref3 === void 0 ? void 0 : ref3.value
                        };
                    })
                };
            });
            setFilas(newData);
        }
    });
    const jornadas = query === null || query === void 0 ? void 0 : (ref2 = query.data) === null || ref2 === void 0 ? void 0 : (ref1 = ref2.data) === null || ref1 === void 0 ? void 0 : ref1.jornadas;
    const getJornada = (id)=>{
        return jornadas === null || jornadas === void 0 ? void 0 : jornadas.find((item)=>{
            var ref;
            return (item === null || item === void 0 ? void 0 : (ref = item.value) === null || ref === void 0 ? void 0 : ref.id) === id;
        });
    };
    const onChangeValue = ({ fila , indexFila , dia , indexDia  })=>{
        return (evt)=>{
            var ref;
            _src_services_api__WEBPACK_IMPORTED_MODULE_3__/* ["default"]["private"] */ .Z["private"]().post(_src_services_urls__WEBPACK_IMPORTED_MODULE_4__/* .urlUpdateOrCreateHorario */ .Ck, {
                enfermeraId: fila === null || fila === void 0 ? void 0 : fila.id,
                fecha: dia === null || dia === void 0 ? void 0 : dia.date,
                jornadaId: (ref = evt.value) === null || ref === void 0 ? void 0 : ref.id
            });
            filas[indexFila].dias[indexDia] = {
                ...dia,
                jornada: evt.value
            };
            setFilas([
                ...filas
            ]);
        };
    };
    const leftContents = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_10___default().Fragment), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            label: "Agregar",
            icon: primereact_api__WEBPACK_IMPORTED_MODULE_7__.PrimeIcons.PLUS,
            sm: true,
            outlined: true,
            className: "p-mr-2"
        })
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        loading: {
            loading: query.isLoading || queryHorarios.isLoading
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
            className: "container-fluid",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_toolbar__WEBPACK_IMPORTED_MODULE_9__.Toolbar, {
                        left: leftContents,
                        className: "w-full"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 p-0 m-0",
                        style: {
                            overflowX: 'auto'
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                            className: "table table-bordered table-responsive-xl",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("thead", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "text-center align-vertical-middle",
                                                    rowSpan: 3,
                                                    children: "No."
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "text-center align-vertical-middle",
                                                    rowSpan: 3,
                                                    children: "Enfermera/o"
                                                }),
                                                Object.entries(fechas).map(([key, value])=>{
                                                    var ref;
                                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "text-center",
                                                        colSpan: value === null || value === void 0 ? void 0 : (ref = value.dias) === null || ref === void 0 ? void 0 : ref.length,
                                                        children: key
                                                    }, `Mes.${key}`));
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                            children: Object.entries(fechas).map(([key, value])=>{
                                                return value.dias.map((dia)=>{
                                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "text-center",
                                                        children: dia === null || dia === void 0 ? void 0 : dia.str
                                                    }, `DiasStr.${key}.${dia === null || dia === void 0 ? void 0 : dia.date}`));
                                                });
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                            children: Object.entries(fechas).map(([key, value])=>{
                                                return value.dias.map((dia)=>{
                                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "text-center",
                                                        children: dia === null || dia === void 0 ? void 0 : dia.number
                                                    }, `DiasNumber.${key}.${dia === null || dia === void 0 ? void 0 : dia.date}`));
                                                });
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: filas.map((fila, index)=>{
                                        var ref6;
                                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_10___default().Fragment), {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "text-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "align-vertical-middle",
                                                        children: index + 1
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "align-vertical-middle p-0 m-0",
                                                        children: fila === null || fila === void 0 ? void 0 : fila.label
                                                    }),
                                                    fila === null || fila === void 0 ? void 0 : (ref6 = fila.dias) === null || ref6 === void 0 ? void 0 : ref6.map((dia, indexDia)=>{
                                                        var ref8, ref5;
                                                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "text-center p-0 m-0 align-vertical-middle",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_8__.Dropdown, {
                                                                className: "p-inputtext-sm rounded-0 dropdown__horario w-100",
                                                                options: query === null || query === void 0 ? void 0 : (ref8 = query.data) === null || ref8 === void 0 ? void 0 : (ref5 = ref8.data) === null || ref5 === void 0 ? void 0 : ref5.jornadas,
                                                                panelClassName: "p-0 m-0 dropdown__horario",
                                                                dataKey: "id",
                                                                value: dia === null || dia === void 0 ? void 0 : dia.jornada,
                                                                dropdownIcon: null,
                                                                onChange: onChangeValue({
                                                                    fila,
                                                                    indexFila: index,
                                                                    dia,
                                                                    indexDia
                                                                }),
                                                                itemTemplate: (item)=>{
                                                                    var ref, ref7;
                                                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        style: {
                                                                            backgroundColor: item === null || item === void 0 ? void 0 : (ref = item.value) === null || ref === void 0 ? void 0 : ref.color,
                                                                            color: item === null || item === void 0 ? void 0 : (ref7 = item.value) === null || ref7 === void 0 ? void 0 : ref7.colorLetra
                                                                        },
                                                                        className: "w-full text-center px-0 py-2 font-bold",
                                                                        children: item === null || item === void 0 ? void 0 : item.label
                                                                    }));
                                                                },
                                                                valueTemplate: (item)=>{
                                                                    var ref, ref9;
                                                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        style: {
                                                                            backgroundColor: item === null || item === void 0 ? void 0 : (ref = item.value) === null || ref === void 0 ? void 0 : ref.color,
                                                                            color: item === null || item === void 0 ? void 0 : (ref9 = item.value) === null || ref9 === void 0 ? void 0 : ref9.colorLetra,
                                                                            height: '34.06px'
                                                                        },
                                                                        className: "w-full text-center font-bold d-flex flex-column justify-content-center border-0",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            children: (item === null || item === void 0 ? void 0 : item.label) || 'SELEC'
                                                                        })
                                                                    }));
                                                                }
                                                            })
                                                        }, dia === null || dia === void 0 ? void 0 : dia.fecha));
                                                    })
                                                ]
                                            })
                                        }, fila.id));
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};
GeneracionHorarioPage.getInitialProps = ({ query  })=>query
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GeneracionHorarioPage);


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 2250:
/***/ ((module) => {

module.exports = require("primereact/api");

/***/ }),

/***/ 1088:
/***/ ((module) => {

module.exports = require("primereact/button");

/***/ }),

/***/ 1404:
/***/ ((module) => {

module.exports = require("primereact/dropdown");

/***/ }),

/***/ 4130:
/***/ ((module) => {

module.exports = require("primereact/menubar");

/***/ }),

/***/ 5767:
/***/ ((module) => {

module.exports = require("primereact/progressspinner");

/***/ }),

/***/ 8345:
/***/ ((module) => {

module.exports = require("primereact/scrolltop");

/***/ }),

/***/ 603:
/***/ ((module) => {

module.exports = require("primereact/toolbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,285,253,663,469,630,49], () => (__webpack_exec__(4371)));
module.exports = __webpack_exports__;

})();