"use strict";
(() => {
var exports = {};
exports.id = 197;
exports.ids = [197];
exports.modules = {

/***/ 1401:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8663);
/* harmony import */ var _src_components_Forms_CheckOptionsInline__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3211);
/* harmony import */ var _src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5776);
/* harmony import */ var _src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7066);
/* harmony import */ var _src_components_Forms_DropDown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2475);
/* harmony import */ var _src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3633);
/* harmony import */ var _src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5002);
/* harmony import */ var _src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3237);
/* harmony import */ var _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(470);
/* harmony import */ var _src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1630);
/* harmony import */ var _src_services_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8469);
/* harmony import */ var _src_services_urls__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6102);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2250);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(primereact_api__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5641);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5828);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(uuid__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__, _src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_16__, _src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__, _src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__, _src_components_Forms_CheckOptionsInline__WEBPACK_IMPORTED_MODULE_2__, _src_components_Forms_DropDown__WEBPACK_IMPORTED_MODULE_5__]);
([_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__, _src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_16__, _src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__, _src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__, _src_components_Forms_CheckOptionsInline__WEBPACK_IMPORTED_MODULE_2__, _src_components_Forms_DropDown__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);



















const FichaIngresoFormPage = ({ id , crudAction  })=>{
    var ref, ref1, ref2, ref3;
    const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_16__.useForm)({
        mode: 'onChange'
    });
    const queryCatalogo = (0,react_query__WEBPACK_IMPORTED_MODULE_17__.useQuery)([
        'pacientes-ficha-catalogo'
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_11__/* ["default"]["private"] */ .Z["private"]().get(_src_services_urls__WEBPACK_IMPORTED_MODULE_12__/* .urlCatalogoForm */ .So)
    );
    (0,react_query__WEBPACK_IMPORTED_MODULE_17__.useQuery)([
        'pacientes-ficha',
        id
    ], ()=>_src_services_api__WEBPACK_IMPORTED_MODULE_11__/* ["default"]["private"] */ .Z["private"]().get((0,_src_services_urls__WEBPACK_IMPORTED_MODULE_12__/* .urlDetailFichasIngreso */ .tF)(id))
    , {
        enabled: id !== undefined && crudAction === _src_emuns_crudActions__WEBPACK_IMPORTED_MODULE_9__/* .CrudActions.UPDATE */ .M.UPDATE,
        onSuccess: ({ data  })=>{
            console.log(data);
            methods.reset(data);
        },
        refetchOnWindowFocus: false
    });
    const method = (0,react__WEBPACK_IMPORTED_MODULE_15__.useMemo)(()=>({
            create: 'post',
            editar: 'put'
        })
    , []);
    const url = (0,react__WEBPACK_IMPORTED_MODULE_15__.useMemo)(()=>({
            create: _src_services_urls__WEBPACK_IMPORTED_MODULE_12__/* .urlCreateFichasIngreso */ .X4,
            editar: (0,_src_services_urls__WEBPACK_IMPORTED_MODULE_12__/* .urlUpdateFichasIngreso */ .fY)(id)
        })
    , []);
    const mutation = (0,react_query__WEBPACK_IMPORTED_MODULE_17__.useMutation)((formData)=>_src_services_api__WEBPACK_IMPORTED_MODULE_11__/* ["default"]["private"] */ .Z["private"]()[method[crudAction]](url[crudAction], formData)
    );
    const onSubmit = async (formData)=>{
        try {
            await mutation.mutateAsync(formData);
            console.log(formData);
            next_router__WEBPACK_IMPORTED_MODULE_13___default().push('/fichas/ingreso');
        } catch (error) {
            console.log(error);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_layouts_PrivateLayout__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        title: "Ficha ingreso",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
            className: "container-fluid",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-center d-flex justify-content-center my-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            className: "align-self-center",
                            rounded: true,
                            sm: true,
                            outlined: true,
                            icon: primereact_api__WEBPACK_IMPORTED_MODULE_14__.PrimeIcons.ARROW_LEFT,
                            href: "/fichas/ingreso"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "align-self-center",
                            children: "Ficha Ingreso"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_16__.FormProvider, {
                    ...methods,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        className: "row justify-content-center",
                        onSubmit: methods.handleSubmit(onSubmit),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:col-8 lg:col-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "paciente",
                                        className: "w-full font-bold",
                                        children: "Buscar paciente: *"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_DropDown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        controller: {
                                            name: 'paciente',
                                            rules: {
                                                required: 'Este campo es obligatorio'
                                            }
                                        },
                                        options: (queryCatalogo === null || queryCatalogo === void 0 ? void 0 : (ref = queryCatalogo.data) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.pacientes) || [],
                                        block: true,
                                        filter: true,
                                        filterMatchMode: "contains",
                                        showClear: true
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        name: "paciente"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:col-8 lg:col-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "paciente",
                                        className: "w-full font-bold",
                                        children: "Buscar Habitaci\xf3n: *"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_DropDown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        controller: {
                                            name: 'habitacion',
                                            rules: {
                                                required: 'Este campo es obligatorio'
                                            }
                                        },
                                        options: (queryCatalogo === null || queryCatalogo === void 0 ? void 0 : (ref2 = queryCatalogo.data) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.data) === null || ref3 === void 0 ? void 0 : ref3.habitaciones) || [],
                                        block: true,
                                        showClear: true,
                                        optionLabel: "label",
                                        optionGroupLabel: "label",
                                        optionGroupChildren: "items",
                                        filter: true,
                                        filterMatchMode: "contains",
                                        optionGroupTemplate: (option)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "d-flex flex-column",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: option.label
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "ms-1",
                                                        children: "Habitaciones:"
                                                    })
                                                ]
                                            })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        name: "habitacion"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                children: "INFORMACI\xd3N GENERAL"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "my-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "contenido.viveCon",
                                                        className: "font-bold",
                                                        children: "VIVE CON: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        controller: {
                                                            name: 'contenido.viveCon',
                                                            rules: {
                                                                required: 'Este campo es obligatorio'
                                                            }
                                                        },
                                                        block: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        name: "contenido.viveCon"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "my-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "contenido.ocupacionAnterior",
                                                        className: "font-bold",
                                                        children: "OCUPACI\xd3N ANTERIOR: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        controller: {
                                                            name: 'contenido.ocupacionAnterior',
                                                            rules: {
                                                                required: 'Este campo es obligatorio'
                                                            }
                                                        },
                                                        block: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        name: "contenido.ocupacionAnterior"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "my-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "contenido.ocupacionActual",
                                                        className: "font-bold",
                                                        children: "OCUPACI\xd3N ACTUAL: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        controller: {
                                                            name: 'contenido.ocupacionActual',
                                                            rules: {
                                                                required: 'Este campo es obligatorio'
                                                            }
                                                        },
                                                        block: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        name: "contenido.ocupacionActual"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "d-flex flex-row flex-wrap justify-content-between",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "contenido.motivoConsulta",
                                                        className: "font-bold",
                                                        children: "MOTIVO DE CONSULTA: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInline__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                        label: "INFORMANTE: *",
                                                        controller: {
                                                            name: 'contenido.informante',
                                                            rules: {
                                                                required: 'Este campo es obligatorio'
                                                            }
                                                        },
                                                        options: [
                                                            {
                                                                labelText: 'USUARIO',
                                                                value: 'USUARIO'
                                                            },
                                                            {
                                                                labelText: 'CUIDADOR',
                                                                value: 'CUIDADOR'
                                                            }, 
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                controller: {
                                                    name: 'contenido.motivoConsulta',
                                                    defaultValue: '',
                                                    rules: {
                                                        required: 'Este campo es obligatorio'
                                                    }
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                name: "contenido.motivoConsulta"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "row justify-content-between",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        className: "col-12 font-bold md:col-6",
                                                        htmlFor: "contenido.enfermedades",
                                                        children: "2. ENFERMEDADES O PROBLEMA ACTUAL: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                        className: "md:text-right col-12 md:col-6",
                                                        children: "CRONOLOG\xcdA, LOCALIZACI\xd3N, CARACTER\xcdSTICAS, INTENSIDAD, CAUSA APARENTE, FACTORES QUE AGRAVAN O MEJORAN, S\xcdNTOMAS ASOCIADOS, EVOLUCI\xd3N, RESULTADOS DE EX\xc1MENES ANTERIORES"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "mb-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        controller: {
                                                            name: 'contenido.enfermedades',
                                                            defaultValue: '',
                                                            rules: {
                                                                required: 'Este campo es obligatorio'
                                                            }
                                                        },
                                                        block: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        name: "contenido.enfermedades"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "mb-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "contenido.medicamentos",
                                                        children: "MEDICAMENTOS QUE INGIERE: *"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        controller: {
                                                            name: 'contenido.medicamentos',
                                                            defaultValue: '',
                                                            rules: {
                                                                required: 'Este campo es obligatorio'
                                                            }
                                                        },
                                                        block: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_ErrorMessage__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        name: "contenido.medicamentos"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "d-flex flex-row flex-wrap",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInline__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    label: "ESTADO GENERAL: *",
                                                    controller: {
                                                        name: 'contenido.estadoGeneral',
                                                        rules: {
                                                            required: 'Es necesario seleccionar un tipo de estado general'
                                                        }
                                                    },
                                                    options: [
                                                        {
                                                            labelText: 'DEPENDIENTE',
                                                            value: 'DEPENDIENTE'
                                                        },
                                                        {
                                                            labelText: 'FR\xc1GIL',
                                                            value: 'FR\xc1GIL'
                                                        },
                                                        {
                                                            labelText: 'INDEPENDIENTE',
                                                            value: 'INDEPENDIENTE'
                                                        }, 
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "d-flex flex-column m-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row flex-wrap justify-content-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "my-1",
                                                    children: "3. REVISI\xd3N ACTUAL DE SISTEMAS: "
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "REDONDO = CON PATOLOG\xcdA: DESCRIBIR"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "CUADRADO = SIN PATOLOG\xcdA: NO DESCRIBIR"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    options: [
                                                        {
                                                            labelText: '1. VISI\xd3N',
                                                            controller: {
                                                                name: 'contenido.sistemas.vision'
                                                            },
                                                            valueCirculo: 'VISI\xd3N-PATOLOGIA',
                                                            valueCuadrado: 'VISI\xd3N-SIN-PATOLOGIA'
                                                        },
                                                        {
                                                            labelText: '2. AUDICI\xd3N',
                                                            controller: {
                                                                name: 'contenido.sistemas.audicion'
                                                            },
                                                            valueCirculo: 'AUDICI\xd3N-PATOLOGIA',
                                                            valueCuadrado: 'AUDICI\xd3N-SIN-PATOLOGIA'
                                                        },
                                                        {
                                                            labelText: '3. OLFATO Y GUSTO',
                                                            controller: {
                                                                name: 'contenido.sistemas.olfatoGusto'
                                                            },
                                                            valueCirculo: 'OLFATO Y GUSTO-PATOLOGIA',
                                                            valueCuadrado: 'OLFATO Y GUSTO-SIN-PATOLOGIA'
                                                        },
                                                        {
                                                            labelText: '4. RESPIRATORIO',
                                                            controller: {
                                                                name: 'contenido.sistemas.respiratorio'
                                                            },
                                                            valueCirculo: 'RESPIRATORIO-PATOLOGIA',
                                                            valueCuadrado: 'RESPIRATORIO-SIN-PATOLOGIA'
                                                        },
                                                        {
                                                            labelText: '5. CARDIOVASCULAR',
                                                            controller: {
                                                                name: 'contenido.sistemas.cardiovascular'
                                                            },
                                                            valueCirculo: 'CARDIOVASCULAR-PATOLOGIA',
                                                            valueCuadrado: 'CARDIOVASCULAR-SIN-PATOLOGIA'
                                                        },
                                                        {
                                                            labelText: '6. DIGESTIVO',
                                                            controller: {
                                                                name: 'contenido.sistemas.digestivo'
                                                            },
                                                            valueCirculo: 'DIGESTIVO-PATOLOGIA',
                                                            valueCuadrado: 'DIGESTIVO-SIN-PATOLOGIA'
                                                        }, 
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    controller: {
                                                        name: 'contenido.sistemas.observaciones'
                                                    },
                                                    block: true
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "d-flex flex-column m-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row flex-wrap justify-content-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "my-1",
                                                    children: "4. ANTECEDENTES PERSONALES: "
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "REDONDO = CON PATOLOG\xcdA: DESCRIBIR"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "CUADRADO = SIN PATOLOG\xcdA: NO DESCRIBIR"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            label: "ALERTAS DE RIESGO",
                                                            options: [
                                                                {
                                                                    labelText: '1. CA\xcdDA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.alertasRiesgo.caida'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. DISMOVILIDAD',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.alertasRiesgo.dismovilidad'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. P\xc9RDIDA DE PESO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.alertasRiesgo.perdidaPeso'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. ASTENIA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.alertasRiesgo.astenia'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. DESORIENTACI\xd3N',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.alertasRiesgo.desorientacion'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. ALTERACIONES DEL COMPORTAMIENTO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.alertasRiesgo.alteracionesComportamiento'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesPersonales.alertasRiesgo.observaciones'
                                                            },
                                                            block: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                            label: "GENERALES",
                                                            options: [
                                                                {
                                                                    labelText: '1. INMUNIZACIONES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.inmunizaciones'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. HIGIENE GENERAL',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.higieneGeneral'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. HIGIENE ORAL',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.higieneOral'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. EJERCICIO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.ejercicio'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. ALIMENTACI\xd3N',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.alimentacion'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. ACTIVIDAD RECREATIVA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.actividadRecreativa'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '8. ALERGIAS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.alergias'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '9. OTROS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.generales.otros'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            label: "HABITOS NOCIVOS",
                                                            options: [
                                                                {
                                                                    labelText: '1. TABASQUISMO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.habitosNocivos.tabaquismo'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. ALCOHOLISMO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.habitosNocivos.alcoholismo'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. ADICCIONES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.habitosNocivos.adicciones'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. OTRO HABITO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.habitosNocivos.otro'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesPersonales.habitosNocivos.observaciones'
                                                            },
                                                            block: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                            label: "CL\xcdNICO QUIRURGICOS",
                                                            options: [
                                                                {
                                                                    labelText: '1. DERMATOLOGICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.dermatologicos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. VISUALES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.visuales'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. OTORRINO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.otorrino'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. ESTOMATOLOGICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.estomatologicos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. ENDOCRINOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.endocrinos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. CARDIO VASCULARES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.cardiovasculares'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '7. RESPIRATORIOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.respiratorios'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '8. DIGESTIVOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.digestivos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '9. NEUROLOGICO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.neurologico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '10. UROL\xd3GICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.urologico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '11. HEMO LINFATICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.hemolinfatico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '12. INFECCIOSOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.infeccioso'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '13. TRONCOLOGICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.troncologico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '14. MUSCULO ESQUELETICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.musculoesqueletico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '15. PSIQUIATRICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.clinicoquirurgicos.psiquiatrico'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesPersonales.clinicoquirurgicos.observaciones'
                                                            },
                                                            block: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            label: "GINECO OBSTETRICOS",
                                                            options: [
                                                                {
                                                                    labelText: '1. EDAD DE MENOPAUSIA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.edadmenopausia'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. EDAD DE ULTIMA MAMOGRAFIA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.edadmamografia'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. EDAD DE ULTIMA CITOLOGIA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.edadcitologia'
                                                                    },
                                                                    value: 'ADICCIONES'
                                                                },
                                                                {
                                                                    labelText: '4. EMBARAZOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.embarazo'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. PARTOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.parto'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. CESAREAS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.cesarea'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '7. TERAPIA HORMONAL',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.ginecoobstetricos.terapiahormonal'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesPersonales.ginecoobstetricos.observaciones'
                                                            },
                                                            block: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            label: "ANDROLOGICOS",
                                                            options: [
                                                                {
                                                                    labelText: '1. EDAD DE ULTIMO ANTIGENO PROSTATICO',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.andrologicos.antigenoprostatico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. TERAPIA HORMONAL',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.andrologicos.terapiahormonal'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesPersonales.andrologicos.observaciones'
                                                            },
                                                            block: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            label: "FARMACOLOGICOS",
                                                            options: [
                                                                {
                                                                    labelText: '1. AINES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.aines'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. ANALGESICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.analgesicos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. ANTIDIABETICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.antidiabeticos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. ANTIHIPERTENSIVOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.antihipertensivos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. ANTICOAGULANTES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.anticoagulantes'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. PSICO FARMACOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.psicofarmacos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '7. ANTIBIOTICOS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.antibioticos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '8. OTROS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.otros'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '9. NUMERO DE PRESCRIPTORES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.farmacologicos.numeroprescriptores'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesPersonales.famarcologicos.observaciones'
                                                            },
                                                            block: true
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "d-flex flex-column m-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row flex-wrap justify-content-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "my-1",
                                                    children: "5. ANTECEDENTES FAMILIARES Y SOCIALES: "
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "REDONDO = CON PATOLOG\xcdA: DESCRIBIR"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "CUADRADO = SIN PATOLOG\xcdA: NO DESCRIBIR"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                            options: [
                                                                {
                                                                    labelText: '1. CARDIOPATAS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.cardiopata'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. DIABETES',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.diabetes'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. HIPERTENSION ARTERIAL',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesPersonales.antecedentes.hipertension arterial'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. NEOPLASIA',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.neoplasia'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. ALZHEIMER',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.alzheimer'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. PARKINSON',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.parkinson'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '7. TUBERCULOSIS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.tuberculosis'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '8. VIOLENCIA INTRAFAMILIAR',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.violenciaintrafamiliar'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '9. SINDROME DEL CUIDADOR',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.sindromecuidador'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '10. OTROS',
                                                                    controller: {
                                                                        name: 'contenido.antecedentesFamiliares.antecedentes.otros'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.antecedentesFamiliares.antecedentes.observaciones'
                                                            },
                                                            block: true
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                className: "my-1",
                                                children: "6. SIGNOS VITALES, ANTROPOMETRIA Y TAMIZAJE: "
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "d-flex flex-row flex-wrap justify-content-around",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.presionAterial.sentado.numerador",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "P. ARTERIAL ACOSTADO"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                            id: "contenido.signosVitales.presionAterial.sentado.numerador",
                                                                            className: "text-center",
                                                                            style: {
                                                                                maxWidth: '6rem'
                                                                            },
                                                                            controller: {
                                                                                name: 'contenido.signosVitales.presionAterial.acostado.numerador'
                                                                            }
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                            className: "text-center",
                                                                            style: {
                                                                                maxWidth: '6rem'
                                                                            },
                                                                            controller: {
                                                                                name: 'contenido.signosVitales.presionAterial.acostado.denominador'
                                                                            }
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.presionAterial.sentado.numerador",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "P. ARTERIAL SENTADO"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                            id: "contenido.signosVitales.presionAterial.sentado.numerador",
                                                                            className: "text-center",
                                                                            style: {
                                                                                maxWidth: '6rem'
                                                                            },
                                                                            controller: {
                                                                                name: 'contenido.signosVitales.presionAterial.sentado.numerador'
                                                                            }
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                            className: "text-center",
                                                                            style: {
                                                                                maxWidth: '6rem'
                                                                            },
                                                                            controller: {
                                                                                name: 'contenido.signosVitales.presionAterial.sentado.denominador'
                                                                            }
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.temperatura",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "TEMPERATURA C"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.temperatura",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.temperatura'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.pulSo",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "PULSO / mm"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.pulSo",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.pulSo'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center ",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.frecuencoaRespiratoria",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "FRECUENCIA RESPIR. / mm"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.frecuencoaRespiratoria",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.frecuencoaRespiratoria'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "d-flex flex-row flex-wrap justify-content-around",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.peso",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "PESO / kg"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.peso",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.peso'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.talla",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "TALLA / cm"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.talla",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.talla'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.imc",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "IMC"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.imc",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.imc'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.perimetroCintura",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "PERIMETRO CINTURA"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.perimetroCintura",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.perimetroCintura'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.perimetroCadera",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "PERIMETRO CADERA"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.perimetroCadera",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.perimetroCadera'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.perimetroPantorrilla",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "PERIMETRO PANTORRILLA"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.perimetroPantorrilla",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.perimetroPantorrilla'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "d-flex flex-column text-center justify-content-between",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "contenido.signosVitales.responsableSiglas",
                                                                style: {
                                                                    maxWidth: '10rem'
                                                                },
                                                                children: "RESPONSABLE SIGLAS"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "w-100",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "p-inputgroup justify-content-center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextInput__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                        id: "contenido.signosVitales.responsableSiglas",
                                                                        className: "text-center",
                                                                        style: {
                                                                            maxWidth: '6rem'
                                                                        },
                                                                        controller: {
                                                                            name: 'contenido.signosVitales.responsableSiglas'
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "d-flex flex-row flex-wrap justify-content-between",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                        label: "TAMIZAJE RAPIDO",
                                                        options: [
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.dificultadVisual'
                                                                },
                                                                labelText: '1. DIFICULTAD VISUAL'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.dificultadAuditiva'
                                                                },
                                                                labelText: '2. DIFICULTAD AUDITIVA'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.levantateAndaMayora15s'
                                                                },
                                                                labelText: '3. "LEVANTATE Y ANDA" MAYOR A 15s'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.perdidaInvoluntariaOrina'
                                                                },
                                                                labelText: '4. PERDIDA INVOLUNTARIA DE ORINA'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.perdidaMemoriaReciente'
                                                                },
                                                                labelText: '5. PERDIDA DE MEMORIA RECIENTE'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.pierdePeso'
                                                                },
                                                                labelText: '6. PIERDE PESO MAS DE 4.5KG EN 5 MESES'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.tristeDeprimido'
                                                                },
                                                                labelText: '7. SE SIENTE TRISTE DEPRIMIDO'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.baniarseSolo'
                                                                },
                                                                labelText: '8. PRUEBA BA\xd1ARSE SOLO'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.saleComprasSola'
                                                                },
                                                                labelText: '9. SALE DE COMPRAS SOLO'
                                                            },
                                                            {
                                                                controller: {
                                                                    name: 'contenido.signos.tamizajeRapido.viveSolo'
                                                                },
                                                                labelText: '10. VIVE SOLO'
                                                            }, 
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "d-flex flex-column m-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row flex-wrap justify-content-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                    className: "my-1 font-bold",
                                                    children: "7. EXAMEN F\xcdSICO: "
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "my-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "REDONDO = CON PATOLOG\xcdA: DESCRIBIRCON EL NUMERO"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                            children: "CUADRADO = SIN PATOLOG\xcdA: NO DESCRIBIR"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                            label: "REGIONAL (1-14)",
                                                            options: [
                                                                {
                                                                    labelText: '1. PIEL',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.piel'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. CABEZA',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.cabeza'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. OJOS',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.ojos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. O\xcdDOS',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.oidos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. BOCA',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.boca'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. NARIZ',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.nariz'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '7. CUELLO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.cuello'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '8. AXILA-MAMA',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.axilamama'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '9. TORAX',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.torax'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '10. ABDOMEN',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.abdomen'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '11. COLUMNA',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.columna'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '12. PERIN\xc9',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.perine'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '13. M. SUPERIORES',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.msuperiores'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '14. M. INFERIORES',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.regional.opciones.minferiores'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.examenFisico.regional.observaciones'
                                                            },
                                                            block: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsInlineCirculoCuadrado__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                            label: "SISTEMATICO (1-9)",
                                                            options: [
                                                                {
                                                                    labelText: '1. ORG DE LOS SENTIDOS',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.orgsentidos'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '2. RESPIRATORIO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.respiratorio'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '3. CARDIO VASCULAR',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.cardiovascular'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '4. DIGESTIVO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.digestivo'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '5. DENITO URINARIO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.denitourinario'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '6. MUSCULO ESQUELETICO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.musculoesqueletico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '7. ENDOCRINO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.endocrino'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '8. HEMO LINFATICO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.hemolinfatico'
                                                                    }
                                                                },
                                                                {
                                                                    labelText: '9. NEUROL\xd3GICO',
                                                                    controller: {
                                                                        name: 'contenido.examenFisico.sistematico.opciones.neurologico'
                                                                    }
                                                                }, 
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            controller: {
                                                                name: 'contenido.examenFisico.sistematico.observaciones'
                                                            },
                                                            block: true
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                className: "font-bold",
                                                children: "8. DIAGNOSTICOS"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_16__.Controller, {
                                                name: "contenido.diagnosticos.items",
                                                defaultValue: [],
                                                render: ({ field: { value , onChange  }  })=>{
                                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "table-responsive-sm",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                            className: "table table-bordered table-hover table-striped",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        className: "text-center",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                style: {
                                                                                    width: '50px'
                                                                                },
                                                                                children: "#"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                children: "DIAGNOSTICO"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                style: {
                                                                                    width: '50px'
                                                                                },
                                                                                children: "P"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                style: {
                                                                                    width: '50px'
                                                                                },
                                                                                children: "D"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                children: "CIE"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                children: "OPCIONES"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    className: primereact_api__WEBPACK_IMPORTED_MODULE_14__.PrimeIcons.TRASH
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                    children: [
                                                                        value === null || value === void 0 ? void 0 : value.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "text-center font-bold align-vertical-middle p-0 m-0",
                                                                                        children: index + 1
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "align-vertical-middle p-0 m-0",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                            className: "w-100 form-control",
                                                                                            type: "text",
                                                                                            name: `diagnostico.${index}`,
                                                                                            value: item.diagnostico,
                                                                                            onChange: (evt)=>{
                                                                                                const itemIndex = value.findIndex((row)=>row.uuid === item.uuid
                                                                                                );
                                                                                                value[itemIndex].diagnostico = evt.target.value;
                                                                                                onChange([
                                                                                                    ...value
                                                                                                ]);
                                                                                            }
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "text-center align-vertical-middle p-0 m-0",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            name: `estado.${index}`,
                                                                                            className: "w-100 form-check",
                                                                                            checked: item.p,
                                                                                            onChange: (evt)=>{
                                                                                                const itemIndex = value.findIndex((row)=>row.uuid === item.uuid
                                                                                                );
                                                                                                value[itemIndex].p = evt.target.checked;
                                                                                                value[itemIndex].d = false;
                                                                                                onChange([
                                                                                                    ...value
                                                                                                ]);
                                                                                            }
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "text-center align-vertical-middle p-0 m-0",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "w-100 form-check",
                                                                                            name: `estado.${index}`,
                                                                                            checked: item.d,
                                                                                            onChange: (evt)=>{
                                                                                                const itemIndex = value.findIndex((row)=>row.uuid === item.uuid
                                                                                                );
                                                                                                value[itemIndex].d = evt.target.checked;
                                                                                                value[itemIndex].p = false;
                                                                                                onChange([
                                                                                                    ...value
                                                                                                ]);
                                                                                            }
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "align-vertical-middle p-0 m-0",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                            className: "w-100 form-control",
                                                                                            type: "text",
                                                                                            name: `diagnostico.${index}`,
                                                                                            value: item.cie,
                                                                                            onChange: (evt)=>{
                                                                                                const itemIndex = value.findIndex((row)=>row.uuid === item.uuid
                                                                                                );
                                                                                                value[itemIndex].cie = evt.target.value;
                                                                                                onChange([
                                                                                                    ...value
                                                                                                ]);
                                                                                            }
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "align-vertical-middle p-0 m-0",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                                            className: "w-100 form-control",
                                                                                            value: item.opcion,
                                                                                            onChange: (evt)=>{
                                                                                                const itemIndex = value.findIndex((row)=>row.uuid === item.uuid
                                                                                                );
                                                                                                value[itemIndex].opcion = evt.target.value;
                                                                                                onChange([
                                                                                                    ...value
                                                                                                ]);
                                                                                            },
                                                                                            placeholder: "SELECCIONE",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                    value: "",
                                                                                                    children: "SELECCIONE"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                    value: "CLINICO",
                                                                                                    children: "CLINICO"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                    value: "SINDROMICO",
                                                                                                    children: "SINDROMICO"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                    value: "PSICOLOGICO",
                                                                                                    children: "PSICOLOGICO"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                    value: "FUNCIONAL",
                                                                                                    children: "FUNCIONAL"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                    value: "NUTRICIONAL",
                                                                                                    children: "NUTRICIONAL"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                        className: "align-vertical-middle p-0 m-0 text-center",
                                                                                        style: {
                                                                                            width: '50px'
                                                                                        },
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                                            icon: primereact_api__WEBPACK_IMPORTED_MODULE_14__.PrimeIcons.TRASH,
                                                                                            sm: true,
                                                                                            outlined: true,
                                                                                            rounded: true,
                                                                                            text: true,
                                                                                            onClick: ()=>onChange(value.filter((option)=>option.uuid !== item.uuid
                                                                                                ))
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            }, item.uuid)
                                                                        ),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                colSpan: 100,
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                                    block: true,
                                                                                    label: "AGREGAR DIAGNOSTICO",
                                                                                    outlined: true,
                                                                                    sm: true,
                                                                                    onClick: ()=>onChange([
                                                                                            ...value,
                                                                                            {
                                                                                                uuid: uuid__WEBPACK_IMPORTED_MODULE_18___default().v4()
                                                                                            }
                                                                                        ])
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    }));
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_CheckOptionsMultipleInline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                label: "SINDROMES GERIATRICOS",
                                                options: [
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.fragilidad'
                                                        },
                                                        labelText: 'FRAGILIDAD'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.dismovilidad'
                                                        },
                                                        labelText: 'DISMOVILIDAD'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.depresion'
                                                        },
                                                        labelText: 'DEPRESION'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.caida'
                                                        },
                                                        labelText: 'CAIDA'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.delirio'
                                                        },
                                                        labelText: 'DELIRIO'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.malnutricion'
                                                        },
                                                        labelText: 'MALNUTRICION'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.ulcerasPorPresion'
                                                        },
                                                        labelText: 'ULCERAS POR PRESION'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.demencia'
                                                        },
                                                        labelText: 'DEMENCIA'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.incontinencia'
                                                        },
                                                        labelText: 'INCONTINENCIA'
                                                    },
                                                    {
                                                        controller: {
                                                            name: 'contenido.diagnosticos.sindromes.latrogenia'
                                                        },
                                                        labelText: 'LATROGENIA'
                                                    }, 
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                className: "font-bold",
                                                children: "9. PRUEBAS DIAGN\xd3STICAS:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                children: "REGISTRAR LOS EX\xc1MENES DE LABORATORIO Y ESPECIALES SOLICITADOS"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    controller: {
                                                        name: 'contenido.pruebasDiagnosticas.observaciones'
                                                    },
                                                    block: true
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row justify-content-center my-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 border",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column m-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                children: "10. TRATAMIENTO"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                children: "1.FUNCIONAL, 2.NUTRICIONAL, 3.PSICOL\xd3GICO, 4.SOCIAL, 5.EDUCATIVO, 6.FARMACOL\xd3GICO"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Forms_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    controller: {
                                                        name: 'contenido.tratamiento.observaciones'
                                                    },
                                                    block: true
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-8 mt-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row justify-content-around",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                label: "Regresar",
                                                outlined: true,
                                                block: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                label: "Guardar",
                                                outlined: true,
                                                block: true,
                                                type: "submit"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
FichaIngresoFormPage.getInitialProps = ({ query  })=>query
;
FichaIngresoFormPage.help = {
    title: 'Formulario de registro de ficha de ingreso del paciente',
    content: 'Formulario de ingreso de datos de ficha de ingreso del paciente'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FichaIngresoFormPage);

});

/***/ }),

/***/ 3211:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3633);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const CheckOptionsInline = (props)=>{
    const { controller  } = props;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
        ...controller,
        render: ({ field  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex flex-column",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "d-inline-flex flex-wrap",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "me-3 font-bold w-full md:w-max",
                                children: props.label
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "d-inline-flex flex-wrap",
                                children: props.options.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full md:w-max",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            style: {
                                                fontSize: '1.25rem'
                                            },
                                            className: "sm:mr-3",
                                            htmlFor: option.labelText,
                                            children: [
                                                option.labelText,
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "align-self-center ms-2",
                                                    type: "checkbox",
                                                    //   value={option.value}
                                                    checked: field.value === option.value,
                                                    id: option.labelText,
                                                    onChange: ()=>field.onChange(option.value)
                                                })
                                            ]
                                        })
                                    }, option.labelText)
                                )
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ErrorMessage__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        name: controller.name
                    })
                ]
            })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckOptionsInline);

});

/***/ }),

/***/ 5776:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _HiddenField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_HiddenField__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
([_HiddenField__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




const CheckOptionsInlineCirculoCuadrado = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row flex-wrap",
            children: [
                props.label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    className: "me-3 font-bold",
                    children: props.label
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: props.options.map((option)=>{
                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                            ...option.controller,
                            defaultValue: {
                                circuloChecked: false,
                                cuadradoChecked: false,
                                ...option.controller.defaultValue
                            },
                            render: ({ field  })=>{
                                var ref, ref1;
                                return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "d-inline-flex flex-wrap me-5 w-full md:w-max",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "d-inline-flex flex-wrap",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    style: {
                                                        fontSize: '1.25rem'
                                                    },
                                                    className: "me-2",
                                                    children: option.labelText
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HiddenField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    name: `${option.controller.name}.label`,
                                                    defaultValue: option.labelText
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HiddenField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    name: `${option.controller.name}.valueCirculo`,
                                                    defaultValue: option.valueCirculo
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HiddenField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    name: `${option.controller.name}.valueCuadrado`,
                                                    defaultValue: option.valueCuadrado
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "d-inline-block",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "align-self-center checkbox-round",
                                                            type: "checkbox",
                                                            id: `${option.labelText}-circulo`,
                                                            checked: (ref = field.value) === null || ref === void 0 ? void 0 : ref.circuloChecked,
                                                            onChange: (evt)=>field.onChange({
                                                                    circuloChecked: evt.target.checked,
                                                                    cuadradoChecked: false
                                                                })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "align-self-center ms-2 checkbox-cuadrado",
                                                            type: "checkbox",
                                                            checked: (ref1 = field.value) === null || ref1 === void 0 ? void 0 : ref1.cuadradoChecked,
                                                            onChange: (evt)=>field.onChange({
                                                                    cuadradoChecked: evt.target.checked,
                                                                    circuloChecked: false
                                                                })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                }));
                            }
                        }, option.labelText));
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckOptionsInlineCirculoCuadrado);

});

/***/ }),

/***/ 7066:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _HiddenField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_HiddenField__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
([_HiddenField__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);




const CheckOptionsMultipleInline = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row flex-wrap",
            children: [
                props.label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    className: "me-3 w-100 font-bold",
                    children: props.label
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: props.options.map((option)=>{
                        var ref1;
                        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                            ...option.controller,
                            defaultValue: {
                                checked: false,
                                ...(ref1 = option.controller) === null || ref1 === void 0 ? void 0 : ref1.defaultValue
                            },
                            render: ({ field  })=>{
                                var ref;
                                return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "d-inline-flex flex-wrap w-full md:w-max md:mr-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "d-inline-flex flex-wrap",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            style: {
                                                fontSize: '1.25rem'
                                            },
                                            htmlFor: option.labelText,
                                            children: [
                                                option.labelText,
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HiddenField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    name: `${option.controller.name}.label`,
                                                    defaultValue: option.labelText
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HiddenField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    name: `${option.controller.name}.value`,
                                                    defaultValue: option.value
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "align-self-center ms-1",
                                                    type: "checkbox",
                                                    id: option.labelText,
                                                    checked: (ref = field.value) === null || ref === void 0 ? void 0 : ref.checked,
                                                    onChange: (evt)=>{
                                                        field.onChange({
                                                            checked: evt.target.checked
                                                        });
                                                    }
                                                })
                                            ]
                                        })
                                    })
                                }));
                            }
                        }, option.labelText));
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckOptionsMultipleInline);

});

/***/ }),

/***/ 2475:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1404);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(primereact_dropdown__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const DropDown = (props)=>{
    const { controller , ...rest } = props;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
        ...controller,
        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
                id: field.name,
                ...rest,
                className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(rest.className, {
                    'p-invalid': fieldState.invalid,
                    'w-full': props.block
                }),
                ...field,
                placeholder: "SELECCIONAR",
                emptyMessage: "Sin resultados",
                emptyFilterMessage: "Sin resultados"
            })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DropDown);

});

/***/ }),

/***/ 1272:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



const HiddenField = (props)=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
        name: props.name,
        defaultValue: props.defaultValue,
        shouldUnregister: props.shouldUnregister,
        rules: props.rules,
        render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                hidden: true,
                children: JSON.stringify(field.value)
            })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HiddenField);

});

/***/ }),

/***/ 5002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6085);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const TextArea = (props)=>{
    const { controller , ...rest } = props;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.Controller, {
        ...controller,
        render: ({ field , fieldState  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_3___default().Fragment), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_2__.InputTextarea, {
                    id: field.name,
                    ...rest,
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(rest.className, {
                        'p-invalid': fieldState.invalid,
                        'w-full': props.block
                    }),
                    ...field
                })
            })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextArea);

});

/***/ }),

/***/ 470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ CrudActions1)
/* harmony export */ });
var CrudActions1;

(function(CrudActions) {
    CrudActions["CREATE"] = 'create';
    CrudActions["UPDATE"] = 'editar';
    CrudActions["DELETE"] = 'eliminar';
    CrudActions["DETAIL"] = 'detalle';
})(CrudActions1 || (CrudActions1 = {
}));


/***/ }),

/***/ 3218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 2250:
/***/ ((module) => {

module.exports = require("primereact/api");

/***/ }),

/***/ 1088:
/***/ ((module) => {

module.exports = require("primereact/button");

/***/ }),

/***/ 1404:
/***/ ((module) => {

module.exports = require("primereact/dropdown");

/***/ }),

/***/ 9093:
/***/ ((module) => {

module.exports = require("primereact/inputtext");

/***/ }),

/***/ 6085:
/***/ ((module) => {

module.exports = require("primereact/inputtextarea");

/***/ }),

/***/ 4130:
/***/ ((module) => {

module.exports = require("primereact/menubar");

/***/ }),

/***/ 5767:
/***/ ((module) => {

module.exports = require("primereact/progressspinner");

/***/ }),

/***/ 8345:
/***/ ((module) => {

module.exports = require("primereact/scrolltop");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5828:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,285,253,663,469,630,530], () => (__webpack_exec__(1401)));
module.exports = __webpack_exports__;

})();