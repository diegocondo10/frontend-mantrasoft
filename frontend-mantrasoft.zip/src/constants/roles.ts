const ROLES = {
  ENFERMERA: 'ENF',
  DOCTOR: 'DOC',
  ADMIN: 'ADMIN',
};

export default ROLES;
