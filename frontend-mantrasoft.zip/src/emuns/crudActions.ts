export enum CrudActions {
  CREATE = 'create',
  UPDATE = 'editar',
  DELETE = 'eliminar',
  DETAIL = 'detalle',
}
